package aesthetics_evaluation_tool;



public class rules  {
	

	public static String OM="";
	public static String ILW="";
	public static String IM="";
	public static String ICM="";
	public static String DN="";
	
	
	
	
	public String[] rules() {
		// TODO Auto-generated constructor stub
		
		
		// overloaded
	
		
if ( 
		 (main_launcher.nb1 >=0.663) || Math.abs(density.value)>=0.735 || ( Math.abs(density.value)>=0.735 & Math.abs(economy.value)<=0.365 & Math.abs(integrality.value)<=0.465)
	)
				
		{
			OM="Overloaded MUI";
		}
		
		

		
		
		if (  (Math.abs(regularity.value)<=0.345  || 
		(Math.abs(Layout_Uniformity.value)<=0.377 )) || (Math.abs(regularity.value)<=0.345)&(Math.abs(simplicity.value)<=0.380 & Math.abs(Sorting.value)<=0.370) )
		{
			ILW="Incorrect Layout of MUI";
		}
		
		
		
		
		
		
		//Imbalance
		
		if (Math.abs(balance.value)<=0.500 &&Math.abs(repartition.value)<=0.478)
				//Math.abs(Layout_Uniformity.value)<=0.377)
		{
			IM="Imbalance of MUI";
		}
		
		
		
		//System.out.println(balance.value);
		//Incohesion
		
		if ((Math.abs(Cohesion.value)<=0.4233  || (Math.abs(unity.value)<=0.4383) & (Math.abs(Sorting.value)<=0.377)) || Math.abs(Cohesion.value)<=0.4233 & Math.abs(Grouping.value)<=505 )
		{
			ICM="InCohesion of MUI";
		}
		
		//Difficult nav
		if (Math.abs(main_launcher.clarity1)<=0.553)
		{
			DN="Difficult navigation";
		}
		
		
		/*System.out.println(DN+"DN");
		System.out.println(IM+"IM");
		System.out.println(ICM+"ICM");
		System.out.println(OM+"OM");
		System.out.println(ILW+"ILW");*/
		return new String[] {IM, OM, ILW, DN, ICM};
		
		
		
		
		
	}

}
