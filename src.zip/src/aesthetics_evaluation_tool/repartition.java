package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class repartition {
public static double value;
	public double repartition() throws IOException {
		// TODO Auto-generated constructor stub
		
		
		
		int UL=Sorting.ULnew;
		int UR=Sorting.URnew;
		int LL=Sorting.LLnew;
		int LR=Sorting.LRnew;
		//System.out.println(UL+""+UR+""+LL+""+LR);
		//main_launcher ML= new main_launcher();
    	String file=main_launcher.data_File;
    	
    	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
		
		
      double div= (double)(rowTotal-1) /(double)4;
      double fact=(double)fact(div);
   double power=  Math.pow(fact, 4);
 // System.out.println(power);
   double repartition= (double) ( power/  (fact(UL)*fact(LL)*fact(LR)*fact(UR)  ) );
   //System.out.println("reprtiton"+repartition); 
  value =Double.parseDouble(new DecimalFormat("##.###").format(repartition));	
  if (Math.abs(value)>=1)
  {
 	 value=1;
  }
      return Math.abs(value);
      
      
      
      
      
	}

	public static double fact (double n) {
		 double produit = 1.0;
		    for (int i=1; i<=n; i++)
		        produit *= i;
		    return produit;
    }
}
