package aesthetics_evaluation_tool;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class clarity {
	int indice_nature=0;
	int indice_text=0;
	
	public static double value=0;
	public static String [] nature, text,hint;
	public static int btn=0;
	public static int ImageView=0;
	public static int edit=0;
	public static int ImageButton=0;
	
	public static int textbtn=0;
	public static int texthint=0;
	
	public static int nbedit=0;
	public static int nbbutton=0;
	public double clarity() throws IOException {
		// TODO Auto-generated method stub

		
		String file=main_launcher.data_File;
      	
      	InputStream input = new FileInputStream(file);
  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
  		 //row number
  		 int rowTotal = sheet.getLastRowNum();
  	
        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
            rowTotal++;
        }
      	
        for ( int r=0;r<1; r++){     
  			 HSSFRow row     = sheet.getRow(r); 
  			 
  			 //get cell number in each row
  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
  			 
  			 // parse cells values of each row
  			 for (int c=0;c<noOfColumns; c++)
  	    	        
  		        {
  				 
  			 HSSFCell cell= row.getCell(c);
  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
  			 
  			 String text= cell.getStringCellValue();
  			 //System.out.println("text="+text);
  			 if (text.equals("nature"))
  			 {
  				 indice_nature=c; 
  				//System.out.println(indice_width);
  			 }
  			 
  			 if (text.equals("text"))
  			 {
  				indice_text=c; 
  				//System.out.println(indice_height);
  			 } 
  		        }
  			 }
        
         nature=new String[rowTotal]; 
  	   text=new String[rowTotal]; 
  	 hint=new String[rowTotal];	
  	  //fill nature table
        for ( int r=1;r<rowTotal; r++)
        
        {   
      	  HSSFRow row     = sheet.getRow(r); 
      	  
      	  //fill the nature table
      	  for (int c=indice_nature;c<indice_nature+1; c++)
    	        
  	        {
      		  HSSFCell cell= row.getCell(c);
      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
      		  nature[r-1]= (cell.getStringCellValue());
      		  
  	        }
      	  
      	//fill the text table
      	  
      	  for (int c=indice_text;c<indice_text+1; c++)
      	        
  	        {
    		  HSSFCell cell= row.getCell(c);
    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
    		  text[r-1]= (cell.getStringCellValue());
    		  
  	        }
/*//fill the hint table
      	  
      	  for (int c=14;c<15; c++)
      	        
  	        {
    		  HSSFCell cell= row.getCell(c);
    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
    		  hint[r-1]= (cell.getStringCellValue());
    		  
  	        }*/
        }
       
        
        for (int i = 0; i < nature.length-1; ++i) { 
        	
        //	System.out.println("nature::"+nature[i]);	
        }
        
        for (int i = 0; i < text.length-1; ++i) { 
        	
        	//System.out.println("text::"+text[i]);	
        }
        
 for (int i = 0; i < hint.length-1; ++i) { 
        	
        	//System.out.println("hint::"+hint[i]);	
        }
	
        //check for buttons and edittexts with texts
	 for (int i=0;i<nature.length-1;i++)
	 {
		 if (nature[i].equals("Button")){
			 nbbutton++;
			 //System.out.println("number buttons"+nbbutton);
		 for(int j=i;j<i+1;j++)
		 {
			if (!"text=\"none\"".equals(text[j]))
			{textbtn++;
			continue;}
		 }
		 
		
			 
	 }
		 
		
if (nature[i].equals("EditText"))
			 
		 {
			 nbedit++;
			 for(int j=i;j<i+1;j++)
			 {
				if (!"text=\"none\"".equals(text[j]))
				{texthint++;
				continue;}
			 }
		 }

if( nbbutton==0)
{
	 nbbutton=1;textbtn=1;
}
	 
if( nbedit==0)
{
	nbedit=1;texthint=1;
}

	 }
	 
       
	    
	 
		 //check for ImageViews
		 for (int i=0;i<nature.length-1;i++)
		 {
			 if (nature[i].equals("ImageView")){
				 ImageView++;
			 
		 }
		 }
		 
		 //check for ImageButtons
		 for (int i=0;i<nature.length-1;i++)
		 {
			 if (nature[i].equals("ImageButton")){
				 ImageButton++;
			 
		 }
		 }
		 
	 btn=nbbutton-textbtn;
    
     edit=nbedit-texthint;
    
  /*   System.out.println("buttons without texts"+btn);	
     System.out.println("edits without texts"+edit);	
     System.out.println("number buttons"+(nbbutton-1));	
     System.out.println("number edits"+(nbedit-1));	
     System.out.println("number ImageView"+ImageView);	*/
   /*  if (nbbutton==0 & nbedit==0)
     {value=1;}
     else
     {*/
        double clarity= (double) ((textbtn+texthint)/(double)(nbbutton+nbedit));
        //System.out.println("clarity"+clarity);	
        value = Double.parseDouble(new DecimalFormat("##.###").format(clarity));
    // }
       
        return Math.abs(value);
       
        
        
        
        
		
		
	}

}
