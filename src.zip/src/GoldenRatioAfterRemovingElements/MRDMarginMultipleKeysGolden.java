package GoldenRatioAfterRemovingElements;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;
/**
 * @author bessghaiernarjess
 */
public class MRDMarginMultipleKeysGolden {

	 public static int DiiferentMargins=0;
		public static int rowTotal;
		public static String result;
		public static  HSSFSheet sheet;
		static int indice_Row=0;
		public static HSSFRow row1 ;
		public static String	outputFileNew;
		
		@SuppressWarnings({ "deprecation", "static-access" })
		public static void main(String[] args) throws IOException {
			// TODO Auto-generated method stub
			
			int nbRows= GenerateOldGoldenTree.nbRows;
		
			 String file=MLDMarginMultipleKeysGolden.outputFileNew;
		        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
		    	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 sheet = wb.getSheetAt(0); //first sheet
				 //row number
				  rowTotal = sheet.getLastRowNum();
			
		      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		          rowTotal++;
		      }
		
		      MultiMap<Integer, Integer> Multimap1 = new MultiValueMap<>();
		
		      int valWidth;
			   for (int i=1; i<=nbRows;i++)
					
				 { 
			             for ( int r=1;r<rowTotal; r++){     
						 HSSFRow row     = sheet.getRow(r); 
						 
						 //get cell number in each row
						 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
						 
						 // parse cells values of each row
						 for (int c=1;c<2; c++)
				    	        
					        {
							 if (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(c) != null && 
					                   !sheet.getRow(r).getCell(c).toString().equals("")){
						 HSSFCell cell= row.getCell(c);
						// System.out.println("row="+r+"###"+cell.getStringCellValue() );
						 
						     HSSFCell cellrow= row.getCell(6);  			 
					         int val= (int) cellrow.getNumericCellValue();
							 if (val==i)
							 {
								 int valx= (int) cell.getNumericCellValue();
								 Multimap1.put(i,valx);
								 HSSFCell cellW= row.getCell(3);  
								 valWidth=(int) cellW.getNumericCellValue();
								// heights=heights+valHeight+",";
								
							 }

					        }	 
						 
						
			}}
			            
			}
			   
		      
			   //System.out.println("Initial map: " + Multimap1);      
		      
		      
			   String values ="";   
		      
		      
			   
			   Set<Integer> keys = Multimap1.keySet();
				 // iterate through the key set and display key and values

				   for (Integer key: keys) {
					   
						   values=values+Multimap1.get(key)+",";
						  
					    
					   //Collection value1 =Iterables.getFirst(Multimap1.get(key), 1);
					  
					}
		      
				  // System.out.println("Final map: " + values);  
		      
		      
				   String result="";
				   
				    Pattern p = Pattern.compile("([0-9]+)\\]");
				    Matcher m = p.matcher(values);
				    while(m.find())
				    {
				    	result=result+m.group(1)+","; //is your string. do what you want
				    }
				   // System.out.println(result);
				   
				    //System.out.println("different margins are : " + result);
				   
				 String[] Finalvals=null;
				 int[] indexes = null; 
				 Finalvals=result.split(","); 
				 
				 ArrayList<Integer> list = new ArrayList<Integer>(); 
				 for(int k=0;k<Finalvals.length;k++){
						
					//System.out.println("Finalvals"+Finalvals[k]); 
				
						 }	   
		      
		      
				 //get the widths according to the indexes==============
				 //=======================
				 String widths="";
				  for (int i=1; i<=nbRows;i++)
						
					 { 
				             for ( int r=1;r<rowTotal; r++){     
							 HSSFRow row     = sheet.getRow(r); 
							 
							 //get cell number in each row
							 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
							
							 HSSFCell cellrow= row.getCell(6);  			 
					        
					         HSSFCell cellx= row.getCell(1);  
					         if (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(6) != null && 
					                   !sheet.getRow(r).getCell(6).toString().equals("")
					                   && 
					                    sheet.getRow(r).getCell(1) != null && 
					                   !sheet.getRow(r).getCell(1).toString().equals("") ){
					        	 int val= (int) cellrow.getNumericCellValue();
					         int valx= (int) cellx.getNumericCellValue();
							 if (val==i & valx==Integer.parseInt(Finalvals[i-1]))
							 {
								 HSSFCell cellw= row.getCell(3); 
								 if (sheet.getRow(r) != null && 
						                    sheet.getRow(r).getCell(3) != null && 
						                   !sheet.getRow(r).getCell(3).toString().equals("")){
								 int valw= (int) cellw.getNumericCellValue();
								
								 widths=widths+valw+",";
							
									
								 } }}}
					 }
				 
				  //System.out.println("widths are : " + widths);     
		      
		      
				  String[] Finalwidths=null;
				   
				  Finalwidths=widths.split(","); 
				   for(int k=0;k<Finalwidths.length;k++){
						
						//System.out.println("Finalwidths "+Finalwidths[k]); 
						
						
					  
							 }
				 //loop through and return heights

					 //fill final results
					 for ( int r=1;r<=nbRows; r++){     
						 HSSFRow row     = sheet.getRow(r); 
						
					    	 HSSFCell cell11 = row.createCell(11);
						     int finalresult= main_launcher.Framewidth-(Integer.parseInt(Finalvals[r-1])+Integer.parseInt((Finalwidths[r-1]))); 
						     
						     cell11.setCellValue(Math.abs(finalresult));
							 row    = sheet.getRow(0); 
						     HSSFCell cell2 = row.createCell(11);
						     cell2.setCellValue("MRD");
						     list.add(finalresult);
						}
					 countFrequencies(list) ;
					 outputFileNew=file+"G6.xls";
						
					    FileOutputStream fileOut = new FileOutputStream(outputFileNew);
						
						wb.write(fileOut);
						fileOut.flush();
						fileOut.close();
						
						MBDMarginMultipleKeysGolden BD= new MBDMarginMultipleKeysGolden();
						try {
							BD.main(new String[]{});
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

		}
		 public static void countFrequencies(ArrayList<Integer> list) 
		 { 
			 
		 	Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
		 	  
		     for (Integer i : list) { 
		         Integer j = hm.get(i); 
		         hm.put(i, (j == null) ? 1 : j + 1); 
		     } 

		     // displaying the occurrence of elements in the arraylist 
		     for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
		     
		     	//System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times"); 
		    	 if (val.getValue()>1)
		    		 DiiferentMargins++;
		    	 else DiiferentMargins++;
		     } 
		   // System.out.println("Different MRD: " + DiiferentMargins);
		    //recomendations.ICM.setText( recomendations.ICM.getText() +"After removing elements: MRD ::"+DiiferentMargins+"\n");
		 }  
		   
		   
		   
	
}
