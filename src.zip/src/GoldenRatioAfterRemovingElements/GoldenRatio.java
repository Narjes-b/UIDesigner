package GoldenRatioAfterRemovingElements;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;
import MetaDataGeneration.X_Distance;
import OM_Practices.DeleteEmptyElementsRows;

/**
 * @author bessghaiernarjess
 */
public class GoldenRatio {
public static double res;
public static int rowTotal;
public static  HSSFSheet sheet;
static int indice_Col=0;
public static HSSFRow row1 ;
static int indice_width=0;
static int indice_height=0;
public static String	outputFileGoldenRatio;
public static void main(String[] args) throws IOException {
	// TODO Auto-generated method stub
	 
	 String file=OM_Practices.DeleteEmptyElementsRows.outputFileNew1;
     //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
 	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
       rowTotal++;
   }
   int[] results= new int[rowTotal-1];
   int [] wid=new int[rowTotal];
   int [] hei=new int[rowTotal]; 
   //System.out.println(rowTotal-1);
   
   for ( int r=1;r<rowTotal; r++)
	      
   {   
 	  HSSFRow row     = sheet.getRow(r); 
 
 	//fill the width table
 	  for (int c=3;c<4; c++)
	        
	        { if (sheet.getRow(r) != null && 
            sheet.getRow(r).getCell(c) != null && 
           !sheet.getRow(r).getCell(c).toString().equals("")){
 		  HSSFCell cell= row.getCell(c);
 		
 		  wid[r-1]= (int)(cell.getNumericCellValue());
	        }
	        }
 	//fill the height table
	  
	  for (int c=4;c<5; c++)
	        
        { if (sheet.getRow(r) != null && 
        sheet.getRow(r).getCell(c) != null && 
       !sheet.getRow(r).getCell(c).toString().equals("")){
		  HSSFCell cell= row.getCell(c);
		  
		  hei[r-1]= (int)(cell.getNumericCellValue());
		  
        } }
 
   }
   
/*   for (int k = 0; k < wid.length-1; ++k) { 
		System.out.println("wid=="+wid[k]);
			
		}
	
  for (int k = 0; k < hei.length-1; ++k) { 
		System.out.println("hei=="+hei[k]);
		
	}*/
   
   
   
   for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 for (int c=0;c<noOfColumns; c++)
	    	        
		        { if (sheet.getRow(r) != null && 
                sheet.getRow(r).getCell(c) != null && 
               !sheet.getRow(r).getCell(c).toString().equals("")){
				  
			 HSSFCell w= row.getCell(3);
			 int width= (int)(w.getNumericCellValue());
			 HSSFCell h= row.getCell(4);
			 int height= (int)(h.getNumericCellValue());
			
			 results[r-1]=(int)isGolden(height,width);;
		        }}
			 }	  
     
   
   /*for(int i=0; i<results.length;i++)
   {
	   System.out.println("results=="+results[i]); 
   }*/
   for(int i=0; i<results.length;i++)
   {
	   if (results[i]==0)
	   {
		   
		 hei[i]=(int) NewProportion(wid[i]);  
  
	   }
	   else if (results[i]==1)
	   {
		   
		 hei[i]=hei[i];  
  
	   }
   }

 /*  for (int k = 0; k < wid.length-1; ++k) { 
		System.out.println("wid=="+wid[k]);
			
		}
	
   for (int k = 0; k < hei.length-1; ++k) { 
		System.out.println("hei=="+hei[k]);
		
	}*/
   
   
   for ( int r1=1;r1<rowTotal; r1++){     
		 HSSFRow row11     = sheet.getRow(r1); 
		 
		 //get cell number in each row
		 int noOfColumns1 = sheet.getRow(r1).getLastCellNum(); 
		 
		 // parse cells values of each row
		 for (int c1=4;c1<5; c1++)
  	        
	        {if (sheet.getRow(r1) != null && 
            sheet.getRow(r1).getCell(c1) != null && 
           !sheet.getRow(r1).getCell(c1).toString().equals("")){
			 HSSFCell cell1= row11.getCell(c1);
			 cell1.setCellValue(hei[r1-1]);
			 
			 
	        }
	        }}
   
   for ( int r=1;r<rowTotal; r++){     
		 HSSFRow row     = sheet.getRow(r); 
		 
		 //get cell number in each row
		 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		 
		 // parse cells values of each row
		 for (int c=0;c<1; c++)
	        
	        {
			 if (sheet.getRow(r) != null && 
			            sheet.getRow(r).getCell(c) != null && 
			           !sheet.getRow(r).getCell(c).toString().equals("")){ 
		 HSSFCell cell= row.getCell(c);
		// System.out.println("row="+r+"###"+cell.getStringCellValue() );
		 
		String text= cell.getStringCellValue();
		
		HSSFCell celltext= row.getCell(5);  			 
     String val= celltext.getStringCellValue();
			
		if (text.equals("ImageButton") && val.equals("text=\"none\""))
		{
			
			 HSSFCell cell1= row.getCell(3);
			 cell1.setCellValue(48);
			 HSSFCell cell2= row.getCell(4);
			 cell2.setCellValue(96);
		}
	
	        }}}
 
   
   outputFileGoldenRatio=file+"GDRE.xls";
		
	    FileOutputStream fileOut = new FileOutputStream(outputFileGoldenRatio);
		
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
		
		//metaDatagenrationAfterGoldenRatio.X_GoldenDistance XD= new metaDatagenrationAfterGoldenRatio.X_GoldenDistance();
		try {
			GenerateOldGoldenTree.main(new String[]{});
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
   
   
}






static double isGolden(double height, double width) {
    //epsilon defines how fine the resolution would be.
	double epsilon = 0.01;
    
    if(Math.abs((width / height) - ((height + width) / width)) <= epsilon) {
    	// return ((height + width) / width);
    	return 1;
    } else {
    	// return goldenRatio(width, height + width);
    	return 0;
    }
}
   
   



static double NewProportion(double width) {
	
	
	int height=(int) (width/1.618);	
	
	return height;
 
}





}
