package DN_Practices;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.geom.Rectangle2D;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;

import mainMUI.Framework;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;
import restructuring.GenerateSimilarUI;
import MetaDataGeneration.MRDMarginMultipleKeys;
import Recommendations.ColorDetection;
import Recommendations.recomendations;

/**
 * @author bessghaiernarjess
 */
public class Check_ButtonImageWidthAndText {

	//loop through the buttonimages 
	//retrieve their text attribute
	//compute the text length along with the buttonimage width
	//compare
	
	
	 public static int DiiferentMargins=0;
		public static int rowTotal;
		public static Font f;
		public static String result;
		public static  HSSFSheet sheet;
		static int indice_Row=0;
		public static HSSFRow row1 ;
		public static String	outputFileNew;
	public static int TableLength=0;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	
		
	 String file=main_launcher.data_File;
    // String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
 	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
       rowTotal++;
   }
 	
   for ( int r=1;r<rowTotal; r++){     
		 HSSFRow row     = sheet.getRow(r); 
		 
		 //get cell number in each row
		 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		 
		 // parse cells values of each row
		 for (int c=0;c<1; c++)
  	        
	        {
			 
		 HSSFCell cell= row.getCell(c);
		// System.out.println("row="+r+"###"+cell.getStringCellValue() );
		 
		String text= cell.getStringCellValue();
		
		if (text.equals("ImageButton"))
		{
			TableLength++;
			
		}
	
			 }

	        }	   
   //System.out.println("tablelength"+TableLength );
   String[] text=new String[TableLength]; 
   int[] width=new int[TableLength]; 
int k=0;
   for ( int r=1;r<rowTotal; r++){     
		 HSSFRow row     = sheet.getRow(r); 
		 
		 //get cell number in each row
		 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		 
		 // parse cells values of each row
		 for (int c=0;c<1; c++)
	        
	        {
			 
		 HSSFCell cell= row.getCell(c);
		// System.out.println("row="+r+"###"+cell.getStringCellValue() );
		 
		String text1= cell.getStringCellValue();
		
		if (text1.equals("ImageButton"))
		{
			
			 HSSFCell celltext= row.getCell(5);  			 
	         String val= celltext.getStringCellValue();
	         
	         text[k]=val;
	         HSSFCell cellw= row.getCell(3);  			 
	         int width1= (int) cellw.getNumericCellValue();
	         width[k]=width1;
	         k++;
		}
	
			 }
		
	        }	   
   int[] length=new int[TableLength];
   int[] pixels=new int[TableLength];
   int[] dp=new int[TableLength];
   int score=0;
   int bad=0;
   String indices="";
   String indices1="";
   //System.out.println(text.length );
   //System.out.println(width.length );
   
   int dpi=0;
	  
  int size=0;
  
  //Swing window for dpi,font family and font size data 
   
   if ( dpi_font.valid) {
	   size=Integer.parseInt(dpi_font.size.getText());
	   f = new Font(dpi_font.font.getText(), Font.PLAIN, size);
	   dpi=Integer.parseInt(dpi_font.dpi.getText());	    
   
   for (int i = 0; i < text.length; ++i) { 
      	
	 
	  //System.out.println("text::"+text[i]); 
	   }
   boolean testText = false; 
   for (String element : text) { 
       if (!element.equals("text=\"none\"")) { 
           testText = true; 
           break; 
       } 
   } 
   boolean testWidth = false; 
   for (int element : width) { 
       if (element==0) { 
           testWidth = true; 
           break; 
       } 
   } 
   if (testText==false & testWidth==true)
   {
	   GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#2::ImageButton width equals the text width :: √"+"\n");
	   //GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#6::It’s best to pair icons with text labels, especially if the icon does not have obvious meaning :: Violated"+"\n");
	   
   }
   else 
   {
	  
	  /* //calculate length
	   for (int i = 0; i < text.length; ++i) { 
	       	
		   if (!text[i].equals("text=\"none\""))
		   {
	       length[i]=text[i].length()-7;	
	      
	       }
		//  System.out.println("text::"+text[i]); 
		   }
	   //change to pixel
	   
	   for (int i = 0; i < length.length; ++i) { 
	       
		   if (length[i]!=11)
		   {
	     length[i]=length[i]*8;
	
	    	
	       }
		  // System.out.println("length::"+length[i]); 
		   }*/
	   
	   //extract text between text"()"
	   
	   
}
	   
	   for (int i = 0; i < text.length; ++i) 
	   {
		   Pattern pattern = Pattern.compile("\"(.*)\"");
	        Matcher matcher = pattern.matcher(text[i]);
	        if (matcher.find()) {
	        	text[i]=matcher.group(1);
	        	 }
	       // System.out.println("without text:: "+text[i]); 
	   }
	   
	   
	   // compute text pixels
	   for (int i = 0; i < text.length; ++i) 
	   {
		   if (text[i].equals("none")){
			   pixels[i]=0;  
		   }
		   else {
			   int s= getPixelWidthOfString_ForFont(text[i],f);
			   
			   pixels[i]=s; 
		   }
	 
	   }
	   
	   for (int i = 0; i < pixels.length; ++i) 
	   {
		   
	       // System.out.println("pixels:: "+pixels[i]); 
	   }
	   
	   
	   //change to dp
	   
	  

	  for (int i = 0; i < pixels.length; ++i) 
	   {
		   if (pixels[i]==0){
			   dp[i]=0;  
		   }
		   else {
			   int s= pxToDp(pixels[i],dpi);;
			   
			   dp[i]=s; 
		   }
	 
	   }
	   
	   for (int i = 0; i < dp.length; ++i) 
	   {
		   
	       // System.out.println("dp:: "+dp[i]); 
	   }
	   
	   
	   
	   
	int k1=1;
	int k11=0;
	   for (int i = 0; i < width.length; ++i) { 
		   	
	    // System.out.println("width::"+width[i]);
		   // 10 is an epsilon, because labels should not be with the exact size as the icon size
		   if (width[i]!=(dp[i]-10) && width[i]!=0 &&dp[i]!=0)
		   {
			   bad++;
			   k11 =k1+i;
			   indices=indices+i+",";
		   }
		   
		   if (width[i]!=0 &&dp[i]==0)
		   { k11 =k1+i;
			   indices1=indices1+i+",";
		   }
	       }
	   
	    
	   
   }
   
   String[] Finalvals=null;
   Finalvals=indices.split(","); 
   for (int i = 0; i < Finalvals.length; ++i) { 
      	
	    
	 // System.out.println("Finalvals::"+Finalvals[i]); 
	    	
	       } 
   String[] Finalvals1=null;
   Finalvals1=indices1.split(","); 
   int[] Finalvalsint= new int[TableLength];  

   
   
   
   if (bad!=0)   
   {
	   recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- You have "+bad+" ImageButton (s) that truncate(s) text!"+"\n");
	   
	   for (int i = 0; i < Finalvals.length; ++i) { 
		 int x =Integer.parseInt(Finalvals[i])+1;
	   recomendations.DN.setText( recomendations.DN.getText() +"\n"+"ImageButton number "+x +"::Width= " 
	   +width[Integer.parseInt(Finalvals[i])] +"dp, Text width= "+dp[Integer.parseInt(Finalvals[i])]+"dp"+"\n");
	   
	   
	   if (dp[Integer.parseInt(Finalvals[i])]<width[Integer.parseInt(Finalvals[i])])
	   {
		   int c= width[Integer.parseInt(Finalvals[i])]-dp[Integer.parseInt(Finalvals[i])];
		   
		   recomendations.DN.setText( recomendations.DN.getText() +"\n"+"Consider adding characters that take up approximately"+c+" dp to the label"+"\n");
		  // GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#6::It’s best to pair icons with text labels, especially if the icon does not have obvious meaning :: √"+"\n");
		   GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#2::ImageButton width equals Text width :: Violated"+"\n");
		   
	   }
	   else if (dp[Integer.parseInt(Finalvals[i])]>width[Integer.parseInt(Finalvals[i])])
	   {
		   int c= dp[Integer.parseInt(Finalvals[i])]-width[Integer.parseInt(Finalvals[i])];
		  
		   recomendations.DN.setText( recomendations.DN.getText() +"\n"+"Consider removing characters that take up approximately"+c+" dp from the label"+"\n");
		   //GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#6::It’s best to pair icons with text labels, especially if the icon does not have obvious meaning :: √"+"\n");
		   GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#2::ImageButton width equals Text width :: Violated"+"\n");
		   
	   }
	   
	    }
	   
   }
   else GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#2::ImageButton width equals Text width ::  √"+"\n");

 /*  for (int i = 0; i < Finalvals1.length; ++i) { 
   if (dp[Integer.parseInt(Finalvals1[i])]==0)
   { int x1 =Integer.parseInt(Finalvals1[i])+1;
	   recomendations.DN.setText( recomendations.DN.getText() +"\n"+"The ImageButton number "+x1 +"::Width= " 
   +width[Integer.parseInt(Finalvals1[i])] +" has no label, you might risk providing an "
	   		+ "unfamiliar icon. Consider adding a label!"+"\n");
	   //GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#6::It’s best to pair icons with text labels, especially if the icon does not have obvious meaning :: Violated"+"\n");
	   
   }}*/
   
   
   if(ColorDetection.countup<4)
   {
   restructuring.GenerateSimilarUI.text1.setText(restructuring.GenerateSimilarUI.text1.getText()+"\n"+"Guideline#3::The Rule of 3 Colors contrast :: √"+"\n");
   }
   else
   { 
   restructuring.GenerateSimilarUI.text1.setText(restructuring.GenerateSimilarUI.text1.getText()+"\n"+"Guideline#3::The Rule of 3 Colors contrast :: Violated"+"\n");}
   
	      
   
   
   
   
   
   
   

	
	}
	
	public static int getPixelWidthOfString_ForFont(String str,Font font){
		  FontMetrics metrics=new FontMetrics(font){
		  }
		;
		  Rectangle2D bounds=metrics.getStringBounds(str,null);
		  return (int)bounds.getWidth();
		}
	public static int pxToDp(int px, int dpi)
	{int dp =(int) (px /(int) (dpi/160));
		//int dp =(int) (px * dpi + 0.5f);
	return dp;
	}
	
}
