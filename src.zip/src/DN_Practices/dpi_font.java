package DN_Practices;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
/**
 * @author bessghaiernarjess
 */
public class dpi_font {
	public static final Color Gold = new Color(255,204,51);
	public static int result;
	public static JTextField font, size, dpi;
	public static boolean valid;
	public static JPanel P3;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  
		   
		    font = new JTextField("ariel",10);
		   
		  // font.setText("Font Family");
		  size = new JTextField("11",10);
		   //size.setText("text size");
		    dpi = new JTextField("240",10);
		  
		   JPanel P1= new JPanel();
		   JPanel P2= new JPanel();
		   JLabel Font= new JLabel("Font Family: ");
		   JLabel SIZE= new JLabel("Font Size:");
		   JLabel f= new JLabel("\"Ariel\", \"TimesRoman\"...");
		   f.setForeground(Color.GRAY);
		   JLabel s= new JLabel("12,14,...");
		   s.setForeground(Color.GRAY);
		   JLabel Sdpi= new JLabel("Screen dpi: ");
		   JLabel empty= new JLabel("160,240...");
		   empty.setForeground(Color.GRAY);
		  // empty.setVisible(false);
		P3= new JPanel();
		   
		/*   
		  
		   */
		   
		   GroupLayout layout = new GroupLayout(P3);
		   P3.setLayout(layout);

		   // Turn on automatically adding gaps between components
		   layout.setAutoCreateGaps(true);

		   // Turn on automatically creating gaps between components that touch
		   // the edge of the container and the container.
		   layout.setAutoCreateContainerGaps(true);

		   // Create a sequential group for the horizontal axis.

		   GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

		   // The sequential group in turn contains two parallel groups.
		   // One parallel group contains the labels, the other the text fields.
		   // Putting the labels in a parallel group along the horizontal axis
		   // positions them at the same x location.
		   //
		   // Variable indentation is used to reinforce the level of grouping.
		   hGroup.addGroup(layout.createParallelGroup().
		            addComponent(Font).addComponent(SIZE).addComponent(Sdpi));
		   hGroup.addGroup(layout.createParallelGroup().
		            addComponent(font).addComponent(size).addComponent(dpi));
		   hGroup.addGroup(layout.createParallelGroup().
		            addComponent(f).addComponent(s).addComponent(empty));
		   layout.setHorizontalGroup(hGroup);

		   // Create a sequential group for the vertical axis.
		   GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

		   // The sequential group contains two parallel groups that align
		   // the contents along the baseline. The first parallel group contains
		   // the first label and text field, and the second parallel group contains
		   // the second label and text field. By using a sequential group
		   // the labels and text fields are positioned vertically after one another.
		   vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE).
				   addComponent(Font).addComponent(font).addComponent(f));
		   vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE).
				   addComponent(SIZE).addComponent(size).addComponent(s));
		   vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE).
				   addComponent(Sdpi).addComponent(dpi).addComponent(empty));
		   layout.setVerticalGroup(vGroup);
		  
		   result = JOptionPane.showConfirmDialog(null, P3, "Icons font related information",JOptionPane.PLAIN_MESSAGE);
		  
		   validateFeed();
		  
		   
	   
	}
	 private static boolean validateFeed() {
	        valid = true;
	        if (result == JOptionPane.CLOSED_OPTION) {
            }
	        else if (font.getText().trim().length() == 0 ||size.getText().trim().length() == 0||dpi.getText().trim().length() == 0) {
	            JOptionPane.showMessageDialog(null, "Fields must not be empty!", "Error", JOptionPane.ERROR_MESSAGE);
	            result = JOptionPane.showConfirmDialog(null, P3, "Font related information",JOptionPane.PLAIN_MESSAGE);
	            validateFeed();
	            valid = false;
	        }
	        else  if (!font.getText().matches("^[a-zA-Z]+$"))
           {
        	   JOptionPane.showMessageDialog(null, "Font family must be a string!", "Error", JOptionPane.ERROR_MESSAGE);
	            result = JOptionPane.showConfirmDialog(null, P3, "Font related information",JOptionPane.PLAIN_MESSAGE);
	            validateFeed();
	            valid = false; 
           }
	        else if (!size.getText().matches("^-?\\d+$"))
           {
        	   JOptionPane.showMessageDialog(null, "Font size must be an integer!", "Error", JOptionPane.ERROR_MESSAGE);
	            result = JOptionPane.showConfirmDialog(null, P3, "Font related information",JOptionPane.PLAIN_MESSAGE);
	            validateFeed();
	            valid = false; 
           }
	        else if (!dpi.getText().matches("^-?\\d+$"))
           {
        	   JOptionPane.showMessageDialog(null, "Screen dpi must be an integer!", "Error", JOptionPane.ERROR_MESSAGE);
	            result = JOptionPane.showConfirmDialog(null, P3, "Font related information",JOptionPane.PLAIN_MESSAGE);
	            validateFeed();
	            valid = false; 
           }
	        
	        return valid;
	    }

}
