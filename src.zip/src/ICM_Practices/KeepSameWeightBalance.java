package ICM_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateSimilarUI;
import aesthetics_evaluation_tool.main_launcher;
import IM_Practices.BalanceWeightOfElements;
import Recommendations.recomendations;

/**
 * @author bessghaiernarjess
 */
public class KeepSameWeightBalance {
	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_X=0;
	public static int nbColumns;
	public static String	outputFileNew;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
int nbCMP= main_launcher.taille1;
		int[]resolutions= new int[nbCMP];
	        
	       String file=MetaDataGeneration.MTDMarginMutliplekeys.outputFileNew;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    
	      
	      int rows= restructuring.GenerateOldMUITree.nbRows;
			int counter=0;
	      for (int i=1;i<=rows;i++)
			{
			
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		
					 HSSFCell cell= row.getCell(6);
						//System.out.println("row="+r+"###"+cell.getStringCellValue() );
					
						 int R= (int) cell.getNumericCellValue();	
						 //System.out.println(R );
					if (R==i)
					{
						counter++;
						 HSSFCell width= row.getCell(3);
						 HSSFCell height= row.getCell(4);
						 
						 int w= (int) width.getNumericCellValue();		
						 int h= (int) height.getNumericCellValue();	
						 int resolution=w*h;
						 //System.out.println(resolution );
						 resolutions[r-1]=resolution;	
					}
		    		
			        
				 }	}  
	        
			
			
		
	      for (int i=0;i<resolutions.length;i++)
			{
		
	    	  //System.out.println("res"+resolutions[i] );
			}
		
		
	// SPLIT ARRAY into 2
	      
	  	int n = resolutions.length;

		int[] half1 = new int[(n + 1)/2];
		int[] half2 = new int[n - half1.length];

		for (int i = 0; i < n; i++)
		{
			if (i < half1.length)
				half1[i] = resolutions[i];
			else
				half2[i - half1.length] = resolutions[i];
		}

		/*System.out.println(Arrays.toString(half1));
		System.out.println(Arrays.toString(half2));
		*/
		
		
	int low1=0;
	int high1=0;
	
	for (int i = 1; i < half1.length; i++)
	{
		int first=half1[i-1];
		if (first<=half1[i])
		{
			low1++;
		}
		else high1++;
	}	
		
		
	/*System.out.println(low1);
	System.out.println(high1);
		*/
		
		
	int low2=0;
	int high2=0;
	
	for (int i = 1; i < half2.length; i++)
	{
		int first=half2[i-1];
		if (first<=half2[i])
		{
			low2++;
		}
		else high2++;
	}	
		
		
	/*System.out.println(low2);
	System.out.println(high2);	*/
		
	if (low1>high1 && low2>high2)
	{
		recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"-- Your MUI has a low to heavy widgets weight. Perfectly sorted out");
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#9::Layouts should be visually balanced  :: Violated"+"\n");
	}
		
	else if (high1>low1 && high2>low2)	
		
	{
		recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"-- Your MUI has a heavy to low widgets weight");
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#9::Layouts should be visually balanced  :: Violated"+"\n");
	}	
		
	
	else if (low1>high1 && low2<high2)
	{
		recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"--the bigger weight is located in the middle of the MUI. The topper and bottom sides are lighter in weight");
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#9::Layouts should be visually balanced  :: Violated"+"\n");
	}
		
	else if (high1>low1 && high2<low2)	
		
	{
		recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"-- the bigger weights are located in the upper and bottom sides of the MUI. The middle is almost empty in terms of weight");
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#9::Layouts should be visually balanced  :: Violated"+"\n");
	}	
	
else if (Math.abs(high1-low1)==2  && Math.abs(high2-low2)==2)	
		
	{
	recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"-- Your MUI is perfectly balanced in weight");
	GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#9::Layouts should be visually balanced  :: √"+"\n");
	
	}
else {recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"-- Your MUI is perfectly balanced in weight");
GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#9::Layouts should be visually balanced  :: √"+"\n");
}
	}


}
