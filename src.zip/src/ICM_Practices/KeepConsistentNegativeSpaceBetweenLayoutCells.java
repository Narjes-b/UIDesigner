package ICM_Practices;

/**
 * @author bessghaiernarjess
 */
public class KeepConsistentNegativeSpaceBetweenLayoutCells {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
