package ICM_Practices;

import restructuring.GenerateSimilarUI;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.economy;

/**
 * @author bessghaiernarjess
 */
public class KeepSameWeightRatios {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int taille=	economy.occf;
		
		if (taille>13)
		{
			recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"-- The application of the Golden ratio resulted in "+taille
					+ " different widgets sizes"+"\n");
			recomendations.ICM.setText( recomendations.ICM.getText() +"\n"+"Consider reducing "+ (taille-7)+ " widgets sizes"+"\n");
			
	        	GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#8::Layouts should use aconsistent grid, keylines,and padding :: Violated"+"\n");
				
		}
		else
		{
			
	        	GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#8::Layouts should use aconsistent grid, keylines,and padding :: √"+"\n");
				
		}
		
		
		
		
	}

}
