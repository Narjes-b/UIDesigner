package ILW_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;
import Recommendations.recomendations;

/**
 * @author bessghaiernarjess
 */
public class ReduceNumberOfRows {
	 public static int DiiferentMargins=0;
		public static int rowTotal;
		public static String result;
		public static  HSSFSheet sheet;
		static int indice_Row=0;
		public static HSSFRow row1 ;
		public static String	outputFileNew;
	public static int TableLength=0;
	public static int rows= IM_Practices.GenerateOldGoldenTree.nbRows;
	public static int cols= IM_Practices.ElementsOnEachColumnGolden.nbColumns;
	public static int[]resolutions= new int[rows];
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

	
		
		recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- After Golden Ratio: you have "+rows+" rows and "+cols+" columns");
		recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- After Golden Ratio: you have "+rows+" rows and "+cols+" columns");
		
		
		// how many widgets on a row without removal
		
		
	
		 String file=metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden.outputFileNew;
		    // String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
		 	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 sheet = wb.getSheetAt(0); //first sheet
				 //row number
				  rowTotal = sheet.getLastRowNum();
			
		   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		       rowTotal++;
		   }
		 	
			int counter=0;
		      for (int i=1;i<=rows;i++)
				{
				
		      for ( int r=1;r<rowTotal; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			
						 HSSFCell cell= row.getCell(6);
							//System.out.println("row="+r+"###"+cell.getStringCellValue() );
						
							 int R= (int) cell.getNumericCellValue();	
							 //System.out.println(R );
						if (R==i)
						{
							counter++;
							
							
						}
			    		
				        
					 }
		      //System.out.println("counter"+counter );
		      resolutions[i-1]=counter;	
		      counter=0;
		      }  
		        
				
				
			
		      for (int i=0;i<resolutions.length;i++)
				{
			
		    	  //System.out.println("res"+resolutions[i] );
				}
			
				   
		//get the index of the max value
		
		
		int ind=getIndex( resolutions);
		int index=ind+1;
		//System.out.println("Index position of Maximum value in an array is  :  " + index);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	private static int getIndex(int [] array) {
		// TODO Auto-generated method stub
		int max = resolutions[0];
		int index = 0;

		for (int i = 0; i < resolutions.length; i++) 
		{
			if (max < resolutions[i]) 
			{
				max = resolutions[i];
				index = i;
			}
		}

		
		return index;
	}

}
