package MetaDataGeneration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class MRD {


	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Row=0;
	public static HSSFRow row1 ;
	public static String	outputFileNew;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		int nbColumns= main_launcher.rows1;
		
	       String file=MLD.outputFileNew;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    	
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=7;c<8; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				 int text= (int) cell.getNumericCellValue();
				 //System.out.println("text="+text);
				 
				if (text ==nbColumns)
				{
					
					
					 
					 int layoutW=main_launcher.layoutwidth;
					 HSSFCell cellX2=row.getCell(1);
		        	 int X1=(int) cellX2.getNumericCellValue();
				     
				     HSSFCell cellWidthX1=row.getCell(3);
		        	 int  widthX1=(int) cellWidthX1.getNumericCellValue();
		        	 HSSFCell cell11 = row.createCell(11);
		        	 cell11.setCellValue(Math.abs(layoutW-(X1+widthX1) ));
					 row     = sheet.getRow(0); 
				     HSSFCell cell2 = row.createCell(11);
				     cell2.setCellValue("MRD");
				}
		    		
		    		
			        }
				 }	  
	        
		    
		    outputFileNew=file+"MetaDataFile6.xls";
	   		
	   	    FileOutputStream fileOut = new FileOutputStream(outputFileNew);
	   		
	   		wb.write(fileOut);
	   		fileOut.flush();
	   		fileOut.close();
	   		
	   		MBDMarginMultipleKeys BD= new MBDMarginMultipleKeys();
			try {
				BD.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
	}


}
