package MetaDataGeneration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author bessghaiernarjess
 */
public class Y_Distance {
	public static int rowTotal,Y;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Col=0;
	public static HSSFRow row1 ;
	public static String	outputFileNew;
	public static  ArrayList<Integer> diffY;
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		 ArrayList<Integer> list = new ArrayList<Integer>(); 
		 diffY = new ArrayList<Integer>(); 
	        
	       String file=X_Distance.outputFileNew;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    	
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=7;c<8; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				 int text= (int) cell.getNumericCellValue();
				 //System.out.println("text="+text);
				 
				
		    		  list.add(text);
		    		
			        }
				 }	  
	        
		    countFrequencies(list); 
		    Y=0;
			Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
	    	  
	        for (Integer i : diffY) { 
	            Integer j = hm.get(i); 
	            hm.put(i, (j == null) ? 1 : j + 1); 
	        } 
	  
	        // displaying the occurrence of elements in the arraylist 
	        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 

	        	Y++;
	        	//System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
	        	
	        } 
		    
		    
	        //System.out.println("X=  "+X);
		    outputFileNew=file+"4";
	   		
	   	    FileOutputStream fileOut = new FileOutputStream(outputFileNew);
	   		
	   		wb.write(fileOut);
	   		fileOut.flush();
	   		fileOut.close();
	
	   		MLDMarginMultipleKeys LD= new MLDMarginMultipleKeys();
			try {
				LD.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	   		
	}

	
   public static void countFrequencies(ArrayList<Integer> list) 
   { 
 
   	Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
   	  
       for (Integer i : list) { 
           Integer j = hm.get(i); 
           hm.put(i, (j == null) ? 1 : j + 1); 
       } 
 
       // displaying the occurrence of elements in the arraylist 
       for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 

       	// System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
       	 if (val.getValue()>1)
       	 {
       		 CalculateXDistance(val.getKey());
       	 }
       } 
       
       
       
       
       
   } 
 
	
 
	public static void CalculateXDistance(Integer input) 
   {
   	
   	
   	  for ( int r=1;r<rowTotal; r++){     
   		  HSSFRow row1    = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=7;c<8; c++)
		    	        
			        {
					 
				 HSSFCell cell= row1.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 int text= (int) cell.getNumericCellValue();
				 
				 if (input==text)
			        {
			        
				 //System.out.println("text="+text);
				 for ( int r1=r+1;r1<rowTotal; r1++){     
					 HSSFRow row11     = sheet.getRow(r1); 
					 
					 //get cell number in each row
					 int noOfColumns1 = sheet.getRow(r1).getLastCellNum(); 
					 
					 // parse cells values of each row
					 for (int c1=7;c1<8; c1++)
			    	        
				        {
						 
					 HSSFCell cell1= row11.getCell(c1);
					// System.out.println("row="+r+"###"+cell.getStringCellValue() );
					 
					 int text1= (int) cell1.getNumericCellValue();
					 //System.out.println("text="+text);
				 
			        if (input==text1)
			        {
			        	 
			        	 
			        	 HSSFCell cellY2=row11.getCell(2);
			        	 int Y2=(int) cellY2.getNumericCellValue();
			        	 row1     = sheet.getRow(r);
			        	 HSSFCell cellWidthY1=row1.getCell(4);
			        	 int  widthY1=(int) cellWidthY1.getNumericCellValue();
			        	
			        	 HSSFCell cellY1=row1.getCell(2);
			        	 int  Y1=(int) cellY1.getNumericCellValue();
			        	 
			        	 HSSFCell cell11 = row11.createCell(9);
					     cell11.setCellValue(Math.abs(Y2-(widthY1+Y1))); 
					     diffY.add(Math.abs(Y2-(widthY1+Y1)));
					     row1     = sheet.getRow(0); 
					     HSSFCell cell2 = row1.createCell(9);
					     cell2.setCellValue("Y-Distance-Col");
			        	
			        }
			        
				        }}
			        
			        
			        }}}
   	
   	
   	
   	
   	
   }
	
	
	
	
	
	
	}


