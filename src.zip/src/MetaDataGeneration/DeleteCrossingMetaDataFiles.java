package MetaDataGeneration;

import java.io.File;

/**
 * @author bessghaiernarjess
 */
public class DeleteCrossingMetaDataFiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		if (!(MTDMarginMutliplekeys.outputFileNew.equals(null)))
		{
			File rows = new File(restructuring.GenerateOldMUITree.outputFileNew);
			rows.delete();
			
			
			File cols = new File(Recommendations.ElementsOnEachColumn.outputFileNew);
			cols.delete();
			
			File X = new File(X_Distance.outputFileNew);
			X.delete();
			
			File Y = new File(Y_Distance.outputFileNew);
			Y.delete();
			
			File ML = new File(MLDMarginMultipleKeys.outputFileNew);
			ML.delete();
			
			File MR = new File(MRDMarginMultipleKeys.outputFileNew);
			MR.delete();
			
			File MB = new File(MBDMarginMultipleKeys.outputFileNew);
			MB.delete();
		
			
		}
		
		
		
		
	}

}
