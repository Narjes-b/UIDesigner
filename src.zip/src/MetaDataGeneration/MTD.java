package MetaDataGeneration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class MTD {



	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Row=0;
	public static HSSFRow row1 ;
	public static String	outputFileNew;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		int nbrows= main_launcher.rows1;
		
	       String file=MBD.outputFileNew;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    	
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=6;c<7; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				 int text= (int) cell.getNumericCellValue();
				 //System.out.println("text="+text);
				 
				if (text ==1)
				{
					
					 
					 
					 HSSFCell cellY1=row.getCell(2);
		        	 int Y1=(int) cellY1.getNumericCellValue();
		        	 HSSFCell cell11 = row.createCell(13);
				     cell11.setCellValue( Y1); 
				     
					
					 row    = sheet.getRow(0); 
				     HSSFCell cell2 = row.createCell(13);
				     cell2.setCellValue("MTD");
				}
		    		
		    		
			        }
				 }	  
	        
		    
		    outputFileNew=file+"MetaDataFile.xls";
	   		
	   	    FileOutputStream fileOut = new FileOutputStream(outputFileNew);
	   		
	   		wb.write(fileOut);
	   		fileOut.flush();
	   		fileOut.close();
	   		/*MTDMarginSinglekey TD= new MTDMarginSinglekey();
			try {
				TD.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
			MTDMarginMutliplekeys TD1= new MTDMarginMutliplekeys();
			try {
				TD1.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	   		DeleteCrossingMetaDataFiles files= new DeleteCrossingMetaDataFiles();
			files.main(new String[]{});
	
	}


}
