package MetaDataGeneration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author bessghaiernarjess
 */
public class MLD {

	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Row=0;
	public static HSSFRow row1 ;
	public static String	outputFileNew;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
	       String file=Y_Distance.outputFileNew;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    	
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=7;c<8; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				 int text= (int) cell.getNumericCellValue();
				 //System.out.println("text="+text);
				 
				if (text ==1)
				{
					
					
					 HSSFCell cellX1=row.getCell(1);
		        	 int X1=(int) cellX1.getNumericCellValue();
		        	 
		        	 HSSFCell cell11 = row.createCell(10);
					 
				     cell11.setCellValue( X1); 
				     
					 row     = sheet.getRow(0); 
				     HSSFCell cell2 = row.createCell(10);
				     cell2.setCellValue("MLD");
				}
		    		
		    		
			        }
				 }	  
	        
		    
		    outputFileNew=file+"MetaDataFile5.xls";
	   		
	   	    FileOutputStream fileOut = new FileOutputStream(outputFileNew);
	   		
	   		wb.write(fileOut);
	   		fileOut.flush();
	   		fileOut.close();
	   		
	   		MRDMarginMultipleKeys RD= new MRDMarginMultipleKeys();
			try {
				RD.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}


    }
	
