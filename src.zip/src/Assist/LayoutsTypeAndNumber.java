package Assist;

import java.io.File;
import java.util.List;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

	import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JOptionPane;
import javax.swing.event.*; 

import java.awt.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import Parser.DeleteEmptyRows;
import mainMUI.evaluate;

/**
 * @author bessghaiernarjess
 */
public class LayoutsTypeAndNumber {
	public static String UIXFilePath="/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/step3-RESTRUCTURING/DumpFiles/DumpFiles";
 
    public static String outputFile;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int LinearLayout=0;
	     int FrameLayout=0;
	     int GridLayout=0;
	     int RelativeLayout=0;
	     int CoordinatorLayout=0;
	     int PercentFrameLayout=0;
	     int PercentRelativeLayout=0;
	    int AbsoluteLayout=0;
	    int nblayouts=0;
	   int ListView=0;
		
		
		
		File sourceCode = new File(UIXFilePath );
		
		
		 String[] classesFile = sourceCode.list();
		 for (int i=0; i<classesFile.length; i++){
		// System.out.println(classesFile[i] );
		 BufferedInputStream in = new BufferedInputStream(new FileInputStream(sourceCode.getAbsolutePath() + "/" + classesFile[i])); 
		  
		 StringWriter out = new StringWriter();
	       int b;
	       while ((b=in.read()) != -1)
	           out.write(b);
	       out.flush();
	       out.close();
	      in.close();
	      String Contenu= out.toString();
	   //System.out.println(Contenu);
		
	      
		     String name = "";
		     String[] FinalName=null;
		   
		     String text;
		     int countlayouts=0;
		     String[] widget = null;
		     String regex = "\\bclass=\"android.\\b[a-zA-Z]*.\\b[a-zA-Z]*";
		     Pattern pattern = Pattern.compile(regex);
		     Matcher matcher = pattern.matcher((CharSequence) Contenu);
		    
		     while (matcher.find())
		     {
		    	
		    	 text=matcher.group();
		    	// System.out.println(text.length());
		    	 
		    	 widget= text.split("\\bclass=\"android.\\b[a-zA-Z]*.\\b");
		    	 
		    	  for(int k=0;k<widget.length;k++){
			    		
			    		//System.out.println(widget[k]); 
			    		name= name+widget[k]+",";
			    	 }

		     }
		     
		     
		     //split the string name
		     
		    		
	    		 FinalName=name.split(",,"); 
	    	 
	    		 for(int k=0;k<FinalName.length;k++){
			    		
		    		//System.out.println(FinalName[k]); 
		    		
		    	 }
	    		// System.out.println(FinalName.length); 
		     
	    		 for(int k=0;k<FinalName.length;k++){
			    		
	    			 if(FinalName[k].equals("LinearLayout") )
	    			 { LinearLayout++;}
	    			 else if (FinalName[k].equals("FrameLayout") )	 
	    			 { FrameLayout++;}
	    			 else if (FinalName[k].equals("GridView"))
	    			 { GridLayout++;}
	    			 else if (FinalName[k].equals("GridLayout"))
	    			 { GridLayout++;}
	    			 else if (FinalName[k].equals("ListView"))
	    			 { ListView++;}
	    			 else if (FinalName[k].equals("RelativeLayout") )
	    			 { RelativeLayout++;}
	    			 else if (FinalName[k].equals("CoordinatorLayout") )
	    			 { CoordinatorLayout++;}
	    			 else if (FinalName[k].equals(" PercentFrameLayout") )
	    			 { PercentFrameLayout++;}
	    			 else if (FinalName[k].equals(" PercentRelativeLayout") )
	    			 { PercentRelativeLayout++;}
	    			 else if (FinalName[k].equals(" AbsoluteLayout") )
	    			 { AbsoluteLayout++;}
	    			 nblayouts=LinearLayout+FrameLayout+GridLayout+RelativeLayout+AbsoluteLayout;	
		    	 }
	    		
	    		
	    		 
		 }	
		 
		 
		 System.out.println(nblayouts); 
		 
		 System.out.println("##########################"); 
		 System.out.println("##########################"); 
		 
		 System.out.println(LinearLayout); 
		 System.out.println(FrameLayout); 
		 System.out.println(GridLayout); 
		 System.out.println(RelativeLayout); 
		 System.out.println(CoordinatorLayout); 
		 System.out.println(PercentFrameLayout); 
		 System.out.println(PercentRelativeLayout); 
		 System.out.println(AbsoluteLayout); 
		 System.out.println(ListView); 
	}

}
