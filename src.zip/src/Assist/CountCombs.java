package Assist;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author bessghaiernarjess
 */
public class CountCombs {
	public static final String My_File = "/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/step3-RESTRUCTURING/GitHub/CountCombs.xls";
	
	public static void main(String[] args) throws IOException {
		
	
		// TODO Auto-generated method stub
		int GLFR=0;
		int LF=0;
		int LFR=0;
		int LLF=0;
		int LLFR=0;
		int GLF=0;
		double SommeGLFR=0;	
		double SommeLF=0;	
		double SommeLFR=0;	
		double SommeLLFR=0;	
		double SommeLLF=0;	
		double SommeGLF=0;	
		
		InputStream input = new FileInputStream(My_File);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
     if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
         rowTotal++;
     }
		
     //System.out.println(rowTotal);
		
		//parse each row
     for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			// int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			// GLFR
			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(0)!=null && 
	                    sheet.getRow(r).getCell(1)==null&&
	                   sheet.getRow(r).getCell(2)!=null&&
	                   sheet.getRow(r).getCell(3)!=null &&
	                   sheet.getRow(r).getCell(4)!=null 
	                   ){
	GLFR++;
	
	HSSFCell G= row.getCell(0);	
	HSSFCell L= row.getCell(2);	
	HSSFCell F= row.getCell(3);	
	HSSFCell R= row.getCell(4);	
	double G1= G.getNumericCellValue();
	double L1= L.getNumericCellValue();
	double F1= F.getNumericCellValue();
	double R1= R.getNumericCellValue();
		 
	SommeGLFR=SommeGLFR+(G1+L1+F1+R1); 
			 }
	
			 
	 else if (sheet.getRow(r) != null && 
            sheet.getRow(r).getCell(0)==null && 
            sheet.getRow(r).getCell(1)==null&&
            sheet.getRow(r).getCell(2)!=null&&
            sheet.getRow(r).getCell(3)!=null&&
            sheet.getRow(r).getCell(4)==null 
            ){
LF++;


HSSFCell L= row.getCell(2);	
HSSFCell F= row.getCell(3);	


double L1= L.getNumericCellValue();
double F1= F.getNumericCellValue();

	 
SommeLF=SommeLF+(L1+F1); 
	 
	 
	 
	 }
	
	
	 else if (sheet.getRow(r) != null && 
	            sheet.getRow(r).getCell(0)==null && 
	            sheet.getRow(r).getCell(1)==null&&
	            sheet.getRow(r).getCell(2)!=null&&
	            sheet.getRow(r).getCell(3)!=null &&
	            sheet.getRow(r).getCell(4)!=null
	            ){
	LFR++;
	
	HSSFCell G= row.getCell(0);	
	HSSFCell L= row.getCell(2);	
	HSSFCell F= row.getCell(3);	
	HSSFCell R= row.getCell(4);	
	//double G1= G.getNumericCellValue();
	double L1= L.getNumericCellValue();
	double F1= F.getNumericCellValue();
	double R1= R.getNumericCellValue();
		 
	SommeLFR=SommeLFR+(L1+F1+R1); 
	 
	 
	 
	 }	
	
	 else if (sheet.getRow(r) != null && 
	            sheet.getRow(r).getCell(0)==null && 
	            sheet.getRow(r).getCell(1)!=null&&
	            sheet.getRow(r).getCell(2)!=null&&
	            sheet.getRow(r).getCell(3)!=null &&
	            sheet.getRow(r).getCell(4)==null 
	            ){
	LLF++;
	
	HSSFCell G= row.getCell(0);	
	HSSFCell Li= row.getCell(1);	
	HSSFCell L= row.getCell(2);	
	HSSFCell F= row.getCell(3);	
	HSSFCell R= row.getCell(4);	
	//double G1= G.getNumericCellValue();
	double Li1= Li.getNumericCellValue();
	double L1= L.getNumericCellValue();
	double F1= F.getNumericCellValue();
	//double R1= R.getNumericCellValue();
		 
	SommeLLF=SommeLLF+(Li1+L1+F1); 
	 
	 
	 
	 }	
			 
			 
	 else if (sheet.getRow(r) != null && 
	            sheet.getRow(r).getCell(0)==null && 
	            sheet.getRow(r).getCell(1)!=null&&
	            sheet.getRow(r).getCell(2)!=null&&
	            sheet.getRow(r).getCell(3)!=null&&
	            sheet.getRow(r).getCell(4)!=null 
	            ){
	LLFR++;
	

	//HSSFCell G= row.getCell(0);	
	HSSFCell Li= row.getCell(1);	
	HSSFCell L= row.getCell(2);	
	HSSFCell F= row.getCell(3);	
	HSSFCell R= row.getCell(4);	
	//double G1= G.getNumericCellValue();
	double Li1= Li.getNumericCellValue();
	double L1= L.getNumericCellValue();
	double F1= F.getNumericCellValue();
	double R1= R.getNumericCellValue();
		 
	SommeLLFR=SommeLLFR+(Li1+L1+F1+R1); 
	 
	 
	 }
			 
			 
	 else if (sheet.getRow(r) != null && 
	            sheet.getRow(r).getCell(0)!=null && 
	            sheet.getRow(r).getCell(1)==null&&
	            sheet.getRow(r).getCell(2)!=null&&
	            sheet.getRow(r).getCell(3)!=null &&
	            sheet.getRow(r).getCell(4)==null 
	            ){
	GLF++;
	

	HSSFCell G= row.getCell(0);	
	HSSFCell Li= row.getCell(1);	
	HSSFCell L= row.getCell(2);	
	HSSFCell F= row.getCell(3);	
	HSSFCell R= row.getCell(4);	
	double G1= G.getNumericCellValue();
	//double Li1= Li.getNumericCellValue();
	double L1= L.getNumericCellValue();
	double F1= F.getNumericCellValue();
	//double R1= R.getNumericCellValue();
		 
	SommeGLF=SommeGLF+(G1+L1+F1); 
	 
	 
	 }	
			 
			  

}
     
     System.out.println("GLF=  "+GLF);
     System.out.println("LLFR=  "+LLFR);
     System.out.println("LLF=  "+LLF);
     System.out.println("LFR=  "+LFR);
     System.out.println("LF=  "+LF);
     System.out.println("GLFR=  "+GLFR);
     System.out.println("SommeGLFR=  "+(SommeGLFR/4));
     System.out.println("SommeLFR=  "+(SommeLFR/(198*3)));
     System.out.println("SommeLLFR=  "+(SommeLLFR/(70*4)));
     System.out.println("SommeLF=  "+(SommeLF/(147*2)));
     System.out.println("SommeLLF=  "+(SommeLLF/(69*3)));
     System.out.println("SommeGLF=  "+(SommeGLF/(2*3)));
	}
	

	


}
