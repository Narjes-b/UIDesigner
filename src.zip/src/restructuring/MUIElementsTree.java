package restructuring;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.clarity;
import aesthetics_evaluation_tool.main_launcher;


/**
 * @author bessghaiernarjess
 */
public class MUIElementsTree extends JPanel{

	 JPanel inner;
	 public static final Color Gold = new Color(255,204,51);
	  static JScrollPane scrollPane;
	  int indice_nature=0;
		int indice_text=0;
		
		public static double value=0;
		public static String [] nature, text;
		public void getContent() throws IOException 
		{
			
				
				String file=main_launcher.data_File;
		      	
		      	InputStream input = new FileInputStream(file);
		  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		  		 //row number
		  		 int rowTotal = sheet.getLastRowNum();
		  	
		        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		            rowTotal++;
		        }
		      	
		        for ( int r=0;r<1; r++){     
		  			 HSSFRow row     = sheet.getRow(r); 
		  			 
		  			 //get cell number in each row
		  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		  			 
		  			 // parse cells values of each row
		  			 for (int c=0;c<noOfColumns; c++)
		  	    	        
		  		        {
		  				 
		  			 HSSFCell cell= row.getCell(c);
		  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
		  			 
		  			 String text= cell.getStringCellValue();
		  			 //System.out.println("text="+text);
		  			 if (text.equals("nature"))
		  			 {
		  				 indice_nature=c; 
		  				//System.out.println(indice_width);
		  			 }
		  			 
		  			 if (text.equals("text"))
		  			 {
		  				indice_text=c; 
		  				//System.out.println(indice_height);
		  			 } 
		  		        }
		  			 }
		        
		         nature=new String[rowTotal]; 
		  	   text=new String[rowTotal]; 
		  		
		  	  //fill nature table
		        for ( int r=1;r<rowTotal; r++)
		        
		        {   
		      	  HSSFRow row     = sheet.getRow(r); 
		      	  
		      	  //fill the nature table
		      	  for (int c=indice_nature;c<indice_nature+1; c++)
		    	        
		  	        {
		      		  HSSFCell cell= row.getCell(c);
		      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		      		  nature[r-1]= (cell.getStringCellValue());
		      		  
		  	        }
		      	  
		      	//fill the text table
		      	  
		      	  for (int c=indice_text;c<indice_text+1; c++)
		      	        
		  	        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		    		  text[r-1]= (cell.getStringCellValue());
		    		  
		  	        }
		        }
		       
		        
		        for (int i = 0; i < nature.length-1; ++i) { 
		        	
		        //	System.out.println("nature::"+nature[i]);	
		        }
		        
		        for (int i = 0; i < text.length-1; ++i) { 
		        	
		        	//System.out.println("text::"+text[i]);	
		        }
				
		        inner= new JPanel(new GridLayout(0, 1));
				 inner.setPreferredSize(new Dimension(100, 1000));
				 inner.setBackground(Gold);
				 HashMap<JCheckBox, ArrayList<String>> map = new HashMap<>();
					JCheckBox checkBox;
			        
				
				String cmp;
				String t;
				String blank="::";
		        for (int i = 0; i < nature.length-1; i++) {
		            StringBuilder sb = new StringBuilder();
		            ArrayList<String> a = new ArrayList<>();
		            //test
		               cmp=nature[i];
		                a.add(cmp);
		                t=text[i];
		                sb.append(cmp).append(blank).append(t);
		            

		            checkBox = new JCheckBox(sb.toString().trim());
		            checkBox.setName("CheckBox" + i);
		            checkBox.addItemListener(new checkedElements());
		            map.put(checkBox, a);
		            inner.add(checkBox);
		        }
		     inner.setAutoscrolls(true);
        scrollPane = new JScrollPane(inner);
        scrollPane.setPreferredSize(new Dimension(300,270));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
  
       // inner.add(scrollPane);
       // restructuringMain.design.add(scrollPane);
		}
      
		public static Component getGUI() {
			// TODO Auto-generated method stub
			return scrollPane;
		}

		class checkedElements implements ItemListener{
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			
		}
		}
}
