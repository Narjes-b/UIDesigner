package restructuring;

import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class SaveNewTree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String data=recomendations.IM.getText().trim(); //read contents of text area into 'data'
		  if(data.equals("")) {
		
			 JOptionPane.showMessageDialog(null, "Complete the restructuring of your MUI!!");
			
		 }
		 else
		 {
			// specify the path to the results out put file
			 //PrintStream Output_file= new PrintStream (new File (main_launcher.data_File+"evaluationData.txt" ));
			 try
			 {
			     String filename= main_launcher.data_File+"evaluationData.txt";
			     FileWriter fw = new FileWriter(filename,true); //the true will append the new data
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("MUI New Tree \n");
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			    
			     fw.write(restructuring.GenerateSimilarUI.text2.getText());
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("Guidelines violation status \n");
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			    
			     fw.write(restructuring.GenerateSimilarUI.text1.getText());
			     
			     //appends the string to the file
			     fw.close();
			     JOptionPane.showMessageDialog(null, "The MUI new tree and the guidelines status data has been written !");
				 
			 }
			 catch(IOException ioe)
			 {
			     System.err.println("IOException: " + ioe.getMessage());
			 }
		 

		 }
		
		
	}

}
