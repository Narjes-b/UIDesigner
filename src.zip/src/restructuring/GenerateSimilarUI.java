package restructuring;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import DN_Practices.Check_BottomNavAndTab;
import DN_Practices.Check_ButtonImageWidthAndText;
import ICM_Practices.CopyOfCopyOfKeepSameWeightBalanceAfterGoldenRatioRemoval;
import OM_Practices.GenerateNewMUITree;
import mainMUI.Framework;
import mainMUI.ViewUIComponent;


/**
 * @author bessghaiernarjess
 */
public class GenerateSimilarUI extends javax.swing.JFrame{
	public static final Color Gold = new Color(255,204,51);
	public static GenerateSimilarUI frame;
	static String trace;
	public static JPanel oldTree;
	public static JLabel oldMUITree;
	public static JTextArea  text,text1,text2;
	public static JScrollPane scroll,scroll1,scroll2;
	@SuppressWarnings("static-access")
	public GenerateSimilarUI(){
		 Font font11 = new Font("Lora", Font.BOLD, 12);
		 JPanel globeall= new JPanel();
		 
		//=======================
			//=======================OLD MUI TREE==========
JPanel globe12= new JPanel();
		globe12.setBackground(Gold); 
		 TitledBorder titledBorder12 = BorderFactory.createTitledBorder("Old MUI tree");
		 globe12.setBorder(titledBorder12);
		 //globe12.setBackground(Color.white);
		 globe12.setPreferredSize(new Dimension(320, 470));
			oldTree= new JPanel();
			oldTree.setPreferredSize(new Dimension(10, 430));
			oldTree.setBackground(Gold);
			text= new JTextArea(24,24);
			text.setText(GenerateOldMUITree.result);
			text.setLineWrap(true);
			text.setEditable(false);
			scroll= new JScrollPane();
			scroll.setViewportView(text);
			scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		    scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			oldTree.add(scroll);
			
			JPanel buttons12= new JPanel();
			buttons12.setBackground(Gold);
			JButton Json12= new JButton ("Save old MUI tree");
			Json12.setBackground(Color.black);
			Json12.setForeground(Color.white);
			Json12.setContentAreaFilled(true);
			Json12.setOpaque(true);
			Json12.setFont(font11);
			//SaveJsonFile actionListenerFile12 = new SaveJsonFile (Json12);
			Json12.addActionListener(new actionListenerFile12());
			buttons12.add(Json12);
			globe12.setLayout(new BoxLayout(globe12, BoxLayout.Y_AXIS));
			globe12.add(oldTree);
			globe12.add(buttons12);
			
			
			
			//=======================
			//=======================GUIDELINES=========
		 
			
			 JPanel guidelines= new JPanel();
			 guidelines.setBackground(Gold); 
			 guidelines.setPreferredSize(new Dimension(500, 470));
			 TitledBorder guidelinesborder = BorderFactory.createTitledBorder("Guidelines Violation");
			 guidelines.setBorder(guidelinesborder);
			 guidelines.setBackground(Gold);
			 JPanel lines= new JPanel();
			
			 lines.setPreferredSize(new Dimension(480, 420));
			 lines.setBackground(Gold);
				text1= new JTextArea(26,42);
				//text1.setText(GenerateOldMUITree.result);
				text1.setLineWrap(true);
				text1.setEditable(false);
				scroll1= new JScrollPane();
				scroll1.setViewportView(text1);
				scroll1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			    scroll1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			    lines.add(scroll1);
			    guidelines.add(lines);
			
		/*GenerateOldMUITree old= new GenerateOldMUITree();
		try {
			old.main(new String[]{});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		oldTree.add(old);*/
			JLabel l= new JLabel("--->");
			l.setFont(font11);
			//=======================
			//=======================REFACTORED MUI TREE=========
		 JPanel globe1= new JPanel();
		 globe1.setBackground(Gold); 
		 TitledBorder titledBorder1 = BorderFactory.createTitledBorder("Restructured MUI tree");
		 globe1.setBorder(titledBorder1);
		 globe1.setPreferredSize(new Dimension(320, 470));
		 globe1.setBackground(Gold);
			JPanel UI1= new JPanel();
			UI1.setPreferredSize(new Dimension(10, 400));
			UI1.setBackground(Gold);
			
			text2= new JTextArea(24,24);
			if (OM_Practices.ManualRemovalElements.size==0){
			text2.setText(IM_Practices.CopyOfGenerateOldGoldenTreeFinal.result);
			}else text2.setText(IM_Practices.AfterRemoval.CopyOfGenerateOldGoldenTreeFinal.result);
			text2.setLineWrap(true);
			text2.setEditable(false);
			scroll2= new JScrollPane();
			scroll2.setViewportView(text2);
			scroll2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		    scroll2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		    UI1.add(scroll2);
			
			JPanel buttons1= new JPanel();
			buttons1.setBackground(Gold);
			JButton Json1= new JButton ("Save refactored MUI tree");
			Json1.setBackground(Color.black);
			Json1.setForeground(Color.white);
			Json1.setContentAreaFilled(true);
			Json1.setOpaque(true);
			Json1.setFont(font11);
			//SaveJsonFile actionListenerFile1 = new SaveJsonFile (Json1);
			Json1.addActionListener(new actionListenerFile1());
			buttons1.add(Json1);
			globe1.setLayout(new BoxLayout(globe1, BoxLayout.Y_AXIS));
			globe1.add(UI1);
			globe1.add(buttons1);
			
			
			
			
			//=======================
			//=======================SIMILAR MUI===========
		 
			JPanel globe= new JPanel();
		 TitledBorder titledBorder = BorderFactory.createTitledBorder("Similar existent MUI");
		 globe.setBorder(titledBorder);
		 globe.setBackground(Gold);
			JPanel UI= new JPanel();
			UI.setPreferredSize(new Dimension(10, 400));
			
			JPanel buttons= new JPanel();
			buttons.setBackground(Gold);
			JButton Json= new JButton ("Save Json file");
			Json.setBackground(Color.black);
			Json.setForeground(Color.white);
			Json.setContentAreaFilled(true);
			Json.setOpaque(true);
			Json.setFont(font11);
			SaveJsonFile actionListenerFile = new SaveJsonFile (Json);
			Json.addActionListener(actionListenerFile);
			buttons.add(Json);
			JButton UIimage= new JButton ("Save The UI image");
			UIimage.setBackground(Color.black);
			UIimage.setForeground(Color.white);
			UIimage.setContentAreaFilled(true);
			UIimage.setOpaque(true);
			UIimage.setFont(font11);
			SaveSimilarUIImage actionListenerimage = new SaveSimilarUIImage (UIimage);
			UIimage.addActionListener(actionListenerimage);
			buttons.add(UIimage);
			globe.setLayout(new BoxLayout(globe, BoxLayout.Y_AXIS));
			globe.add(UI);
			globe.add(buttons);
			globe.setBackground(Gold); 
			
			globeall.add(globe12);
			//globeall.add(l);
			globeall.add(globe1);
			globeall.add(guidelines);
			//globeall.add(globe);
			
			globeall.setBackground(Gold); 
			getContentPane().add(globeall);
		
	}
	private static class actionListenerFile1 extends WindowAdapter implements ActionListener
	  {
	 

	    @SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e)
	    {
	      //System.out.println(e.getActionCommand());
	     
	  restructuring.SaveNewTree meta= new restructuring.SaveNewTree();
	 meta.main(new String[]{});}
	  }
	    
	private static class actionListenerFile12 extends WindowAdapter implements ActionListener
	  {
	 

	    @SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e)
	    {
	      //System.out.println(e.getActionCommand());
	     
	  restructuring.SaveOldTree meta= new restructuring.SaveOldTree();
	 meta.main(new String[]{});
	
	    }}
	

	public static void main(String args[]) {
	  try {
          for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
              if ("Nimbus".equals(info.getName())) {
                  javax.swing.UIManager.setLookAndFeel(info.getClassName());
                  break;
              }
          }
      } 
      
    
      catch (ClassNotFoundException ex) {
         java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
      } catch (InstantiationException ex) {	        
          java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
      } catch (IllegalAccessException ex) {	        
          java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
      } catch (javax.swing.UnsupportedLookAndFeelException ex) {	        	
          java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
      }

      /* Create and display the form */
      java.awt.EventQueue.invokeLater(new Runnable() {
          @SuppressWarnings("static-access")
		public void run() {
              try {
            	   frame=new GenerateSimilarUI();
              	    frame.setVisible(true);
					frame.getContentPane().setBackground(Gold);
					frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					
					 frame.setTitle(" Restructuring UI tree ");
					 frame.setSize(1300,500);
					 frame.setLocationRelativeTo(null);
					 
					 
					 //######### GUIDELINES############
					   Check_BottomNavAndTab NT= new Check_BottomNavAndTab();
				        try {
							NT.main(new String[]{});
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
				        Check_ButtonImageWidthAndText IT= new Check_ButtonImageWidthAndText();
				        try {
							IT.main(new String[]{});
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				        
				        DN_Practices.ImageButtonwithText img= new    DN_Practices.ImageButtonwithText();
				        try {
							img.main(new String[]{});
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				        
				        DN_Practices.WidgetsWithText wd= new     DN_Practices.WidgetsWithText();
				        try {
							wd.main(new String[]{});
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				        
				        ILW_Practices.TryTabsOrNavigationDrawer TN= new ILW_Practices.TryTabsOrNavigationDrawer ();
				        TN.main(new String[]{});
				        
				        ILW_Practices.ConsistentTextViews TV= new  ILW_Practices.ConsistentTextViews();
				        try {
							TV.main(new String[]{});
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				        
				       ICM_Practices.KeepSameWeightRatios ratio= new ICM_Practices.KeepSameWeightRatios();
				       ratio.main(new String[]{}); 
				       
				       
				       //////
				       ///////
				       
				       
				       if (OM_Practices.ManualRemovalElements.size==0)
					       
				       { 
				       
				       ICM_Practices.KeepSameWeightBalance balance= new  ICM_Practices.KeepSameWeightBalance();
				       try {
						balance.main(new String[]{});
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				       }
				       
				       else if (OM_Practices.ManualRemovalElements.size!=0)
					       
				       {
				       CopyOfCopyOfKeepSameWeightBalanceAfterGoldenRatioRemoval balanceGolden= new  CopyOfCopyOfKeepSameWeightBalanceAfterGoldenRatioRemoval();
				       try {
						balanceGolden.main(new String[]{});
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				        
				       }
				       
				   //////
				       ///////
				       
				       
				       
				       if (OM_Practices.ManualRemovalElements.size==0)
				       
				       {ILW_Practices.EmptyCells rows= new ILW_Practices.EmptyCells();
				       try {
						rows.main(new String[]{});
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				       
				
				       }
				       
				       if (OM_Practices.ManualRemovalElements.size!=0)
				       {ILW_Practices.EmptyCellsAfterRemoval rows= new ILW_Practices.EmptyCellsAfterRemoval();
				       try {
						rows.main(new String[]{});
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				       
				   //////
				       ///////
				       
				       
				     
				       
				       
				       
				       }
				       
				        
				/*   ILW_Practices.KeepConsistentNegativeSpaceBetweenRowCellsNoRemoval padd= new ILW_Practices.KeepConsistentNegativeSpaceBetweenRowCellsNoRemoval();
				   try {
					padd.main(new String[]{});
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				   
				   
				   ILW_Practices.KeepConsistentNegativeSpaceBetweenColumnsCellsNoRemoval pad= new ILW_Practices.KeepConsistentNegativeSpaceBetweenColumnsCellsNoRemoval();
				   try {
					pad.main(new String[]{});
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
				   
				   
				   
				   
				} catch(NullPointerException e)
              
              {   StringBuilder sb = new StringBuilder(e.toString());
			    for (StackTraceElement ste : e.getStackTrace()) {
			        sb.append("\n\tat ");
			        sb.append(ste);
			    
			    trace = sb.toString();
			
			
		}
			    JOptionPane.showMessageDialog(null, "NullPointerException"+"\n"+"re-check your input!", "Warning", JOptionPane.ERROR_MESSAGE);
      }
              catch(IllegalStateException e)
              
              {   StringBuilder sb = new StringBuilder(e.toString());
			    for (StackTraceElement ste : e.getStackTrace()) {
			        sb.append("\n\tat ");
			        sb.append(ste);
			    
			    trace = sb.toString();
			
			
		}
			    JOptionPane.showMessageDialog(null, "IllegalStateException"+"\n"+"re-check your input!", "Warning", JOptionPane.ERROR_MESSAGE);
      }
      
          }
      });
  }

  
	
	
	
	
	
}
