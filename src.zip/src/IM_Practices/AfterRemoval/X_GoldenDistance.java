package IM_Practices.AfterRemoval;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


import restructuring.GenerateOldMUITree;

/**
 * @author bessghaiernarjess
 */
public class X_GoldenDistance {
	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Row=0;
	public static HSSFRow row1 ;
	public static String	outputFileNew;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		 ArrayList<Integer> list = new ArrayList<Integer>(); 
	        
	        
	       String file=GoldenRatioAfterRemovingElements.MTDMarginMutliplekeysGolden.outputFileNew;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    	
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=6;c<7; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(c) != null && 
		                   !sheet.getRow(r).getCell(c).toString().equals("")){
				 int text= (int) cell.getNumericCellValue();
				 //System.out.println("text="+text);
				 
				
		    		  list.add(text);
		    		
			        }
				 }	  
	      }
		    countFrequencies(list); 
		   
	   		
	   	    FileOutputStream fileOut = new FileOutputStream(file);
	   		
	   		wb.write(fileOut);
	   		fileOut.flush();
	   		fileOut.close();
	   		
	   		IM_Practices.AfterRemoval.Y_GoldenDistance col= new IM_Practices.AfterRemoval.Y_GoldenDistance();
			try {
				col.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

	
	}

	
    public static void countFrequencies(ArrayList<Integer> list) 
    { 
  
    	Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
    	  
        for (Integer i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        // displaying the occurrence of elements in the arraylist 
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 

        	// System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
        	 if (val.getValue()>1)
        	 {
        		 CalculateXDistance(val.getKey());
        	 }
        } 
        
        
        
        
        
    } 
  
	
  
	public static void CalculateXDistance(Integer input) 
    {
    	
    	
    	  for ( int r=1;r<rowTotal; r++){     
    		  HSSFRow row1    = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=6;c<7; c++)
		    	        
			        {
					 
				 HSSFCell cell= row1.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(c) != null && 
		                   !sheet.getRow(r).getCell(c).toString().equals("")){
				 int text= (int) cell.getNumericCellValue();
				 
				 if (input==text)
			        {
			        
				 //System.out.println("text="+text);
				 for ( int r1=r+1;r1<rowTotal; r1++){     
					 HSSFRow row11     = sheet.getRow(r1); 
					 
					 //get cell number in each row
					 int noOfColumns1 = sheet.getRow(r1).getLastCellNum(); 
					 
					 // parse cells values of each row
					 for (int c1=6;c1<7; c1++)
			    	        
				        {
						 
					 HSSFCell cell1= row11.getCell(c1);
					// System.out.println("row="+r+"###"+cell.getStringCellValue() );
					 if (sheet.getRow(r1) != null && 
				                sheet.getRow(r1).getCell(c1) != null && 
				               !sheet.getRow(r1).getCell(c1).toString().equals("")){
					 int text1= (int) cell1.getNumericCellValue();
					 //System.out.println("text="+text);
				 
			        if (input==text1)
			        {
			        	 
			        	 
			        	 HSSFCell cellX2=row11.getCell(1);
			        	 int X2=(int) cellX2.getNumericCellValue();
			        	 row1     = sheet.getRow(r);
			        	 HSSFCell cellWidthX1=row1.getCell(3);
			        	 int  widthX1=(int) cellWidthX1.getNumericCellValue();
			        	
			        	 HSSFCell cellX1=row1.getCell(1);
			        	 int  X1=(int) cellX1.getNumericCellValue();
			        	 
			        	 HSSFCell cell11 = row11.createCell(8);
					     cell11.setCellValue(Math.abs(X2-(widthX1+X1))); 
					     
					     row1     = sheet.getRow(0); 
					     HSSFCell cell2 = row1.createCell(8);
					     cell2.setCellValue("X-Distance-Row");
			        	
			        }
			        
				        }}
			        
				 }
			        }}}}
    	
    	
    	
    	
    	
    }
	
	
	
	
	
	
	
	
	
	
}
