  package IM_Practices.AfterRemoval;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;

import mainMUI.evaluate;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.microsoft.schemas.office.visio.x2012.main.CellType;

import Parser.nativeApps;
import Recommendations.ElementsOnEachColumn;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;
import aesthetics_evaluation_tool.regularity;

/**
 * @author bessghaiernarjess
 */
public class GenerateOldGoldenTree {
	static HSSFRow row,row1;
	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Y=0;
	public static String	outputFileNew;
	public static FileOutputStream fileOut;
	public static int nbRows;
    public static void countFrequencies(ArrayList<Integer> list) 
    { 
  
    	Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
    	  
        for (Integer i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        // displaying the occurrence of elements in the arraylist 
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
          nbRows++;
        	// System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times"); 
        } //System.out.println("IMPractices rowsGenerate"+nbRows);
    } 
  
    @SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException 
    { 
        ArrayList<Integer> list = new ArrayList<Integer>(); 
        
        
       String file=BalanceWeightOfElements.file;
        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
    	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
    	
      for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=2;c<3; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(c) != null && 
	                   !sheet.getRow(r).getCell(c).toString().equals("")){
			 double text= cell.getNumericCellValue();
			 System.out.println("text="+text);
			 
			
	    		  list.add((int)text);
	    		
		        }
			 }	}  
        
	    countFrequencies(list); 
	    orderList(list);
        orderComponentsRows(list);
        
       // outputFileNew =file+"File1.xls";
		
	    fileOut = new FileOutputStream(file);
		
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
		
		IM_Practices.AfterRemoval.ElementsOnEachColumnGolden cola= new IM_Practices.AfterRemoval.ElementsOnEachColumnGolden();
		try {
			cola.main(new String[]{});
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    }
    

	public static void orderList(ArrayList<Integer> list) 
    { 
  
    	Collections.sort(list);
    	 
        //System.out.println("After ArrayList sort " +list);
      
    }
    
    @SuppressWarnings("static-access")
	private static void orderComponentsRows(ArrayList<Integer> list) {
		// TODO Auto-generated method stub
 
    	int size = list.size();
  
//get the elements
    	 
         result="";
         int s=0;
         int r;
         int k=1;
    	 for (int i=0; i<size;i++){
    		
    		 double val= list.get(i); 
    	 for (r=1;r<rowTotal; r++){ 
    		 
 			 row     = sheet.getRow(r); 
 			
 			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
 			 for (int c=2;c<3; c++) {				 
 			 HSSFCell cell= row.getCell(c);	
 			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(c) != null && 
	                   !sheet.getRow(r).getCell(c).toString().equals("")){
 			 double value= cell.getNumericCellValue();
	    	
 			 if (val==value)
 			 { s++;
 				 HSSFCell cellText= row.getCell(0);  			 
  			     String text= cellText.getStringCellValue();
  			     
  			     HSSFCell cellX= row.getCell(1);  			 
  			     int X= (int) cellX.getNumericCellValue();
			     
			     HSSFCell cellY= row.getCell(2);  			 
			     int Y= (int) cellY.getNumericCellValue();
			     
			     HSSFCell cellW= row.getCell(3);  			 
			     int W= (int) cellW.getNumericCellValue();
			     
			     HSSFCell cellH= row.getCell(4);  			 
			     int H= (int) cellH.getNumericCellValue();
			   
  			     //System.out.println("(Row"+(k)+")"+text+"::"+"["+X+","+Y+"]["+W+","+H+"]"+"\n");
			     result=result+"(Row"+(k)+")::"+text+"::"+"["+X+","+Y+"]["+W+","+H+"]"+"\n";
			     HSSFCell cell1 = row.createCell(6);
			     cell1.setCellValue(k); 
			     /*row     = sheet.getRow(0); 
			     HSSFCell cell2 = row.createCell(6);
			     cell2.setCellValue("Row"); */
			    
			     
 			 }
 			 
 		        }
 			 }}
    	 k++;
    	if (s>1)i=s-1;
    	 }
    	 
    	
    
    
	}

    
    
    
    
    
   
    
    
    
    
     
}		
	
