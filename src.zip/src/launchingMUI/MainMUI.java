package launchingMUI;
import java.awt.*;
import java.awt.event.*; 
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;



/**
 * @author bessghaiernarjess
 */
public class MainMUI extends JFrame{
	private static final int kControlA = 65;
	static String longMessage;
	JFrame frame; 
	JPanel eval, recommend, restructure;
	public MainMUI() throws IOException {
		// TODO Auto-generated constructor stub
		 frame= new JFrame();
	        frame.setTitle("Automatic Aesthetic Design Restructuring for Android User Interfaces");
	      //add menu
		    //Add menu bar to our frame
		    MenuBar menuBar = new MenuBar();
		    Menu aboutMenu = new Menu("About");
		    menuBar.add(aboutMenu);
		    
		    frame.setMenuBar(menuBar);
			    longMessage="This Framework aims to provide a tool for designers, developers to:"+"\n "+
		      "-- Evaluate user interfaces: we detect all possible aesthetic issues in the design,"+"\n "
			  +" based on the evaluation of a set of 15 geometrical metrics. Metrics values will help with the "+"\n "+"comprehension of the MUI structure"+"\n "
			  +"-- Remarks: we provide designers/developers with a list of remarks describing the structural"+"\n"+" organization of the MUI"+"\n "
		      +"-- Recommendations: Based on the set of our restructuring operations, we provide the user with "+"\n"+"a set of adaptive restructuring operations based on the structure of the evaluated user interface"+"\n"
			  +"-- Re-design: we consider all the structural points of the user interface, and try to an extent "+"\n"+"apply automatically the proposed recommendations."
			  ;
			    frame.setSize(750, 350);
			    JFrame.setDefaultLookAndFeelDecorated(true);
			   frame.setLocationRelativeTo(null);
			  JPanel globe= new JPanel();
			  globe.setBackground(Color.darkGray);
frame.add(globe);
				 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				 
				 aboutMenu.add(new MenuItem("About V1", new MenuShortcut(kControlA))).addActionListener(new Events());

	        frame.setVisible(true);
			


		  /*  ImageIcon img= new ImageIcon("/Users/bessghaiernarjess/Documents/workspace-luna/Framework/src/launchingMUI/IP9C3G.jpg");
			   JLabel back = new JLabel("",img,JLabel.CENTER);
			 back.setBounds(0,0,600,400);
			 getContentPane().add(back);*/
			 JPanel main= new JPanel();
			 main.setBackground(Color.darkGray);
			 main.setLayout(new FlowLayout());
			 eval= new JPanel();
			 eval.setBackground(Color.darkGray);
		  recommend= new JPanel();
		  recommend.setBackground(Color.darkGray);
			 restructure= new JPanel();
			 restructure.setBackground(Color.darkGray);
			 
			 //image panel eval
			 ImageIcon imageIcon = new ImageIcon("/Users/bessghaiernarjess/Documents/workspace-luna/Framework/src/launchingMUI/evaluate1.png");
			    JLabel label = new JLabel(imageIcon);
			    //label.setBounds(0,0,200,200);
			    eval.add(label);
			    main.add(eval);
			    label.addMouseListener(new MouseAdapter(){
			        public void mouseClicked(MouseEvent e) {
			            System.out.print("image1"
			                    + e.getClickCount() + ")");
			            eval.setBackground(Color.CYAN);
			            recommend.setBackground(Color.darkGray);
			            restructure.setBackground(Color.darkGray);
			        }
			    });
			  //image panel recommend
				 BufferedImage image1 = ImageIO.read(new File("/Users/bessghaiernarjess/Documents/workspace-luna/Framework/src/launchingMUI/recommend.png"));
				    JLabel label1 = new JLabel(new ImageIcon(image1));
				    recommend.add(label1);
				    label1.addMouseListener(new MouseAdapter(){
				        public void mouseClicked(MouseEvent e) {
				            System.out.println("image 2"
				                    + e.getClickCount() + ")");
				            recommend.setBackground(Color.CYAN);
				            restructure.setBackground(Color.darkGray);
				            eval.setBackground(Color.darkGray);
				        }
				    });
				  //image panel restructure
					 BufferedImage image2 = ImageIO.read(new File("/Users/bessghaiernarjess/Documents/workspace-luna/Framework/src/launchingMUI/restructuring.png"));
					    JLabel label2 = new JLabel(new ImageIcon(image2));
					    restructure.add(label2);
					    label2.addMouseListener(new MouseAdapter(){
					        public void mouseClicked(MouseEvent e) {
					            System.out.println("image3 "
					                    + e.getClickCount() + ")");
					            restructure.setBackground(Color.CYAN);
					            eval.setBackground(Color.darkGray);
					            recommend.setBackground(Color.darkGray);
					        }
					    });
					  
				 main.add(recommend);
				 main.add(restructure);
				 globe.add(main);
				 frame.add( globe,BorderLayout.CENTER);

				}
	
	
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new MainMUI();
	}
	private class Events extends WindowAdapter implements ActionListener
	  {
	 

	    public void actionPerformed(ActionEvent e)
	    {
	      System.out.println(e.getActionCommand());
	     
	   
	      if(e.getActionCommand().equalsIgnoreCase("About V1"))
	      { // create a JTextArea
		      JTextArea textArea = new JTextArea(10, 55);
		      textArea.setText(longMessage);
		      textArea.setEditable(false);
		      
		      // wrap a scrollpane around it
		      JScrollPane scrollPane = new JScrollPane(textArea);
		      
		      // display them in a message dialog
		      JOptionPane.showMessageDialog(frame, scrollPane);
	      }
	  
	    }
	  }


	
}
