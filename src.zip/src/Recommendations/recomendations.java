package Recommendations;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*; 
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

import restructuring.GenerateOldMUITree;

/**
 * @author bessghaiernarjess
 */
public class recomendations extends JPanel{
	JPanel recommend;
	public static final Color Gold = new Color(255,204,51);
public static	JButton generateRecommendations;
	public static JTextArea Regularity,balanceW,balanceNB,Clarity,Economy,DN,OM,IM,ICM,ILW;
	public recomendations() {
		// TODO Auto-generated constructor stub
		recommend= new JPanel();
		
		 TitledBorder titledBorder = BorderFactory.createTitledBorder("Generate Recommendations");
		 recommend.setBorder(titledBorder);
		
	}

	public void getContent() 
	{
		 Font font11 = new Font("Lora", Font.BOLD, 12);
		 Font font = new Font("Courier", Font.BOLD,12); 
		 recommend.setLayout(new BoxLayout(recommend,BoxLayout.Y_AXIS));
		
		 recommend.setBackground(Gold);
		
		JPanel P1= new JPanel ();
		   P1.setBackground(Gold);

			JLabel first = new JLabel ("MUI Structural Description:");
			first.setFont(font); 
			JLabel first1 = new JLabel ("------------");
			first1.setFont(font); 
			P1.add(first);
			P1.add(first1);
			recommend.add(P1);
		
			 JTabbedPane tp=new JTabbedPane();  
			  Regularity=new JTextArea(8,25); 
			  Regularity.setLineWrap(true);
			  Regularity.setEditable(false);
			  balanceW=new JTextArea(8,25);
			  balanceW.setLineWrap(true);
			  balanceW.setEditable(false);
			  balanceNB=new JTextArea(8,25);
			  balanceNB.setLineWrap(true);
			  balanceNB.setEditable(false);
			  Clarity=new JTextArea(8,25);
			  Clarity. setLineWrap(true);
			  Clarity .setEditable(false);
			  Economy=new JTextArea(8,25);
			  Economy.setLineWrap(true);
			  Economy.setEditable(false);
			    JPanel p1=new JPanel();  
			    p1.add(Regularity);  
			    JPanel p2=new JPanel();
			    p2.add(balanceW);
			    JPanel p5=new JPanel();
			    p5.add(balanceNB);
			    JPanel p3=new JPanel(); 
			    p3.add(Clarity);
			    JPanel p4=new JPanel(); 
			    p4.add(Economy);
			 tp.setBounds(10,50,30,50);  
			    tp.add("Regularity",p1);  
			    tp.add("Balance/Weight",p2); 
			    tp.add("Balance/NB",p5); 
			    tp.add("Clarity",p3); 
			    tp.add("Economy",p4);
			    JScrollPane scroll = new JScrollPane();
			    scroll.setViewportView(tp);
			    tp.setBackground(Color.black);
			    tp.setForegroundAt(0, Color.ORANGE);
			    tp.setBackgroundAt(0, Color.GREEN);
			    for (int i = 0; i < tp.getTabCount(); i++) {
			        tp.getComponentAt(i).setBackground(Gold);
			    }
		recommend.add(scroll);
		
			JPanel P2= new JPanel ();
			   P2.setBackground(Gold);

				JLabel rec = new JLabel ("MUI Recommendations:");
				rec.setFont(font); 
				JLabel rec1 = new JLabel ("-------------------");
				rec1.setFont(font); 
				P2.add(rec);
				P2.add(rec1);
				recommend.add(P2);

				  generateRecommendations= new JButton("Generate Recommendations");
				 generateRecommendations.setBackground(Color.black);
				 generateRecommendations.setForeground(Color.white);
				 generateRecommendations.setContentAreaFilled(true);
				 generateRecommendations.setOpaque(true);
				 generateRecommendations.setFont(font11);
				 generateRecommendations.setEnabled(false);
				 generateRecommendations.setForeground(Color.black);
				generateRecommendations.addActionListener(new GenerateRecs());
				recommend.add(generateRecommendations);
				
				//UIManager.put("TabbedPane.selected", Color.white);
				JTabbedPane tp1=new JTabbedPane(); 
				UIManager.put("TabbedPane.unselectedForeground", Color.blue);
				UIManager.put("TabbedPane.selectedBackground", Color.red);
				 DN=new JTextArea(17,25); 
				 DN.setLineWrap(true);
				 DN.setEditable(false);
				 OM=new JTextArea(17,25);
				 OM.setLineWrap(true);
				 OM.setEditable(false);
				 IM=new JTextArea(17,25);
				 IM.setLineWrap(true);
				 IM.setEditable(false);
				 ICM=new JTextArea(17,25);
				 ICM.setLineWrap(true);
				 ICM.setEditable(false);
				 ILW=new JTextArea(17,25);
				 ILW.setLineWrap(true);
				ILW .setEditable(false);
				    JPanel p11=new JPanel();  
				    p11.add(DN);  
				    JPanel p21=new JPanel(); 
				    p21.add(OM);
				    JPanel p31=new JPanel();  
				    p31.add(IM);
				    JPanel p41=new JPanel(); 
				    p41.add(ICM);
				    JPanel p51=new JPanel();  
				    p51.add(ILW);
				 tp1.setBounds(50,50,10,10);  
				 
				    JScrollPane scroll1 = new JScrollPane();
				    scroll1.setViewportView(DN);
				    JScrollPane scroll2 = new JScrollPane();
				    scroll2.setViewportView(OM);
				    JScrollPane scroll3 = new JScrollPane();
				    scroll3.setViewportView(IM);
				    JScrollPane scroll4 = new JScrollPane();
				    scroll4.setViewportView(ICM);
				    JScrollPane scroll5 = new JScrollPane();
				    scroll5.setViewportView(ILW);
				    tp1.add("DN",scroll1);
				    tp1.add("OM",scroll2);
				    tp1.add("IM",scroll3);
				    tp1.add("ICM",scroll4);
				    tp1.add("ILW",scroll5);
				    for (int i = 0; i < tp1.getTabCount(); i++) {
				        tp1.getComponentAt(i).setBackground(Gold);
				       
				    }
				    
			recommend.add(tp1);
			
		
	}
	
	class GenerateRecs implements ActionListener {  
		@SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent Event) { 
		if (mainMUI.evaluate.pathimage.getText().isEmpty())
		{
			JOptionPane.showMessageDialog(null, "You did not provide the path to you user interface image", "Warning", JOptionPane.ERROR_MESSAGE);
			
		}
		else {
			
		    DN_Practices.dpi_font dpi= new DN_Practices.dpi_font(); 
		    dpi.main(new String[]{});
			
			FillRecommendsTab recommends= new FillRecommendsTab ();
	  try {
		recommends.main(new String[]{});
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	/*  GenerateOldMUITree tree= new  GenerateOldMUITree ();
      try {
			tree.main(new String[]{});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
      
	  ColorDetection color= new ColorDetection();
      try {
		color.main(new String[]{});
	} catch (IllegalArgumentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (NoSuchFieldException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SecurityException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      /*DN_Practices.Check_ButtonImageWidthAndText t= new   DN_Practices.Check_ButtonImageWidthAndText();
      try {
			t.main(new String[]{});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
      metaDatagenrationAfterGoldenRatio.GoldenRatio GR= new  metaDatagenrationAfterGoldenRatio.GoldenRatio ();
      try {
			GR.main(new String[]{});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      restructuring.restructuringMain.generateDesign.setEnabled(true);
	  restructuring.restructuringMain.generateDesign.setForeground(Color.white);}
	  ElementsFrequency freq= new ElementsFrequency();
		try {
			freq.main(new String[]{});
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	  
	  
		}}
	
	public Component getGUI() {
		// TODO Auto-generated method stub
		return recommend;
	}
	
	
}
