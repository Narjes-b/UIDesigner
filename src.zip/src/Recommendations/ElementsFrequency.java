package Recommendations;
import java.awt.Color;
import java.awt.Font;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import java.util.*; 

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;
/**
 * @author bessghaiernarjess
 */
public class ElementsFrequency {
	static int indice_text=0;
	    public static void countFrequencies(ArrayList<String> list) 
	    { 
	    	

	    	Map<String, Integer> hm = new HashMap<String, Integer>(); 
	    	  
	        for (String i : list) { 
	            Integer j = hm.get(i); 
	            hm.put(i, (j == null) ? 1 : j + 1); 
	        } 
	        int i=1;
	        // displaying the occurrence of elements in the arraylist 
	        for (Map.Entry<String, Integer> val : hm.entrySet()) { 

	        		recomendations.OM.setText( recomendations.OM.getText() + "\n"+i+"\" Element " + val.getKey() + " "
                        + "occur(s)"
                        + ": " + val.getValue() + " time(s)"+"\n");
	        		i++;
	        } 
	    } 
	  
	    public static void main(String[] args) throws IOException 
	    { 
	        ArrayList<String> list = new ArrayList<String>(); 
	        
	        
	        String file=main_launcher.data_File;
	        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	    	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
			 //row number
			 int rowTotal = sheet.getLastRowNum();
		
	      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	          rowTotal++;
	      }
	    	
	      for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=0;c<1; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				 String text= cell.getStringCellValue();
				 //System.out.println("text="+text);
				 
				
		    		  list.add(text);
		    		  
			        }
				
	        
	    }
	      countFrequencies(list); 
	} 
}
