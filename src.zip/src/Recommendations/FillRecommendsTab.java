package Recommendations;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class FillRecommendsTab {
	static int indice_nature=0;
	static int indice_text=0;
	@SuppressWarnings({ "null", "static-access" })
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		//=================DN tab===============
		//===========================================
		

		String file=main_launcher.data_File;
      	
      	InputStream input = new FileInputStream(file);
  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
  		 //row number
  		 int rowTotal = sheet.getLastRowNum();
  	
        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
            rowTotal++;
        }
      	
        for ( int r=0;r<1; r++){     
  			 HSSFRow row     = sheet.getRow(r); 
  			 
  			 //get cell number in each row
  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
  			 
  			 // parse cells values of each row
  			 for (int c=0;c<noOfColumns; c++)
  	    	        
  		        {
  				 
  			 HSSFCell cell= row.getCell(c);
  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
  			 
  			 String text= cell.getStringCellValue();
  			 //System.out.println("text="+text);
  			 if (text.equals("nature"))
  			 {
  				 indice_nature=c; 
  				//System.out.println(indice_width);
  			 }
  			 
  			 if (text.equals("text"))
  			 {
  				indice_text=c; 
  				//System.out.println(indice_height);
  			 } 
  		        }
  			 }
        
        String [] nature=new String[rowTotal]; 
  	  String [] text=new String[rowTotal]; 
  		
  	  //fill nature table
        for ( int r=1;r<rowTotal; r++)
        
        {   
      	  HSSFRow row     = sheet.getRow(r); 
      	  
      	  //fill the nature table
      	  for (int c=indice_nature;c<indice_nature+1; c++)
    	        
  	        {
      		  HSSFCell cell= row.getCell(c);
      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
      		  nature[r-1]= (cell.getStringCellValue());
      		  
  	        }
      	  
      	//fill the text table
      	  
      	  for (int c=indice_text;c<indice_text+1; c++)
      	        
  	        {
    		  HSSFCell cell= row.getCell(c);
    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
    		  text[r-1]= (cell.getStringCellValue());
    		  
  	        }
        }
       
        
        for (int i = 0; i < nature.length-1; ++i) { 
        	
        //	System.out.println("nature::"+nature[i]);	
        }
        
        for (int i = 0; i < text.length-1; ++i) { 
        	
        	//System.out.println("text::"+text[i]);	
        }
	
    	//====================================
		//========Buttons without texts=======
		//====================================
		
        
        int nb=0;
        for (int i=0;i<nature.length-1;i++)
   	 {
   		 if (nature[i].equals("Button")){
   		nb++;
   			 
   		 }}
        //System.out.println(nb);
        int []listButton = new int[nb];
        int m=0;
        for (int i=0;i<nature.length-1;i++)
      	 {
      		 if (nature[i].equals("Button")){
      		
      			 listButton[m]=i;
      			 m++;
      		 }}
           //System.out.println(m);
       
	 for (int i=0;i<listButton.length;i++)
	 {
		
		 for(int j=listButton[i];j<listButton[i]+1;j++)
		 {
			if ("".equals(text[j]))
			{ 
				recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- Consider adding text to button number  "
			+"\""+(i+1)+"\""+
        	"  following a descendent order of the MUI from top to bottom"+"\n");
				
			}
			
		 }
	 }
	
		
		//====================================
				//========TextFields without hints=======
				//====================================
		
	   int nbT=0;
       for (int i=0;i<nature.length-1;i++)
  	 {
  		 if (nature[i].equals("EditText")){
  		nbT++;
  			 
  		 }}
       
	 int []listTextFields = new int[nbT];
     int mT=0;
     for (int i=0;i<nature.length-1;i++)
   	 {
   		 if (nature[i].equals("EditText")){
   		
   			listTextFields[mT]=i;
   			 mT++;
   		 }}
        //System.out.println(mT);
    
	 for (int i=0;i<listTextFields.length;i++)
	 {
		
		 for(int j=listTextFields[i];j<listTextFields[i]+1;j++)
		 {
			if ("".equals(text[j]))
			{ 
				recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- Consider adding hints to TextField number  "
			+"\""+(i+1)+"\""+
     	"  following a descendent order of the MUI from top to bottom"+"\n");
				
			}
			
		 }
	 }
	
		  
		
		
		//====================================
				//========Image Views=======
				//====================================
		
	 if (main_launcher.imagebutton>0)
	 recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- It is recommended to either associate labels to icons or use user-friendly icons "
	 +"\n"+" To verify whether your ImageButtons are representative or familiar, please check this link"+"\n"+"https://www.usertesting.com/blog/user-friendly-ui-icons/"+"\n");
		
	 			
	 if (main_launcher.difficult1=="")
	 {
		 recomendations.DN.setText( recomendations.DN.getText() +"-- Difficult navigation is not detected"+"\n"+
	 "All your used graphical components look descriptive!"+"\n"); 
		 
	 }
	 recomendations.DN.setText( recomendations.DN.getText() +"Color System test------"+"\n");
 	
		//=================OM tab===============
		//===========================================
		
	
	 
	 
	 recomendations.OM.setText( recomendations.OM.getText() +" --you have  "
				+main_launcher.nature1+"  different types"+"\n");
	 
	 recomendations.OM.setText( recomendations.OM.getText() +" --you have  "
				+main_launcher.occ1+" different components sizes"+"\n");
	 
	 if(main_launcher.taille1>=32)
	 {
		 recomendations.OM.setText( recomendations.OM.getText() +" -- Consider removing " +(main_launcher.taille1-31)  +"components"+"\n"+ 
	 "To do so, here is the frequency of your graphical elements occurrence:"+"\n"); 
	 }
	 
	 if(main_launcher.taille1>= 25 & main_launcher.taille1<=31&main_launcher.overloaded1=="")
	 {recomendations.OM.setText( recomendations.OM.getText() +" -- We recommend you to select some of the unecessary elements from the \"Generate New Design\" tab"+"\n"+
	 "To do so, here is the frequency of your graphical elements occurrence:"+"\n");
	 }

	 
	
	 
	 // in case there are lots of textviewsa and empty imageviews
	 

	 // in case 
	 
	 
	 
	 
	 
		//=================IM tab===============
		//===========================================
		
		
		
		
		
		
		
		//=================ICM tab===============
		//===========================================
		
		
		
		
		
		
		
		//=================ILW tab===============
		//===========================================
		
		
		
		
		
		

		
		
		
		
		
		
		
		
	}

}
