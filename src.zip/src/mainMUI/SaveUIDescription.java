package mainMUI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

import javax.swing.JOptionPane;

import Recommendations.recomendations;
import aesthetics_evaluation_tool.Sorting;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class SaveUIDescription {
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		
		
		//Generate output file
		String data=recomendations.IM.getText().trim(); //read contents of text area into 'data'
		  if(main_launcher.data_File==null) {
		
			 JOptionPane.showMessageDialog(null, "You did not evaluate any MUI!!");
			
		 }
		 else
		 {
			// specify the path to the results out put file
			 //PrintStream Output_file= new PrintStream (new File (main_launcher.data_File+"evaluationData.txt" ));
			 try
			 {
			     String filename= main_launcher.data_File+"evaluationData.txt";
			     FileWriter fw = new FileWriter(filename,true); //the true will append the new data
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("MUI description \n");
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("Economy----------------\n");
			     fw.write(recomendations.Economy.getText());
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("Regularity--------------------\n");
			     fw.write(recomendations.Regularity.getText());
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("Balance/number of Widgets----------------\n");
			     fw.write(recomendations.balanceNB.getText());
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("Balance/weight of Widgets--------------------\n");
			     fw.write(recomendations.balanceW.getText());
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     fw.write("Clarity----------------\n");
			     fw.write(recomendations.Clarity.getText());
			     fw.write("----------------------------------\n");
			     fw.write("----------------------------------\n");
			     
			     //appends the string to the file
			     fw.close();
			     JOptionPane.showMessageDialog(null, "The MUI description data has been written !");
				 
			 }
			 catch(IOException ioe)
			 {
			     System.err.println("IOException: " + ioe.getMessage());
			 }
		 

		 }
		
		
	}
		
		
		
}
