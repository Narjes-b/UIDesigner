package mainMUI;

/**
 * @author bessghaiernarjess
 */
public class restructure {

	public restructure() {
		// TODO Auto-generated constructor stub
	}

}
