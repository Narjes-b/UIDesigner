package mainMUI;
import java.awt.*;
import java.awt.event.*; 
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import restructuring.GenerateOldMUITree;
import Parser.hybridApps;
import Parser.nativeApps;
import aesthetics_evaluation_tool.main_launcher;
import Recommendations.FillRecommendsTab;
import Recommendations.recomendations;

/**
 * @author bessghaiernarjess
 */
public class evaluate extends JPanel{
	JPanel evaluate;
	JFrame frame;
	public static final Color Gold = new Color(255,204,51);
	static String  trace;
    JFileChooser chooser;
    public static ButtonGroup group;
    public static JTextField path,pathimage;
	public static JTextField xlspath,fwt,fht,lwt,lht;
    JButton browse,browseimage;
    public static JButton Start,UIdata,parse;
    static JLabel ILWstatus;
	static JLabel ICMstatus;
	static JLabel IMstatus;
	static JLabel OMstatus;
	static JLabel DNstatus;
    public static JPanel metricICM,metricILW,metricIM,metricOM,metricDN;
    public static JRadioButton r1,r2;
	public evaluate() {
		// TODO Auto-generated constructor stub
		 evaluate= new JPanel();
		// evaluate.setBackground(Color.black);
		 TitledBorder titledBorder = BorderFactory.createTitledBorder("Evaluate your MUI");
		evaluate.setBorder(titledBorder);
	
	}

	public void getContent() {
		// TODO Auto-generated method stub
		 Font font11 = new Font("Lora", Font.BOLD, 12);
		 Font font = new Font("Courier", Font.BOLD,12); 
		evaluate.setLayout(new BoxLayout(evaluate,BoxLayout.Y_AXIS));
		
		evaluate.setBackground(Gold);
	
		
		//new
				JPanel MUI= new JPanel ();
				MUI.setBackground(Gold);

				JLabel MUIl = new JLabel ("Enter the MUI image path:");
				MUIl.setFont(font); 
				JLabel MUIll = new JLabel ("---------------------------------");
				MUIll.setFont(font); 
				MUI.add(MUIl);
				MUI.add(MUIll);
				evaluate.add(MUI);
				
				
				JPanel image= new JPanel();
				image.setBackground(Gold);
				 pathimage= new JTextField("",30);
				pathimage.setEditable(false);
				//path.setAlignmentX(JTextField.LEFT_ALIGNMENT);
				browseimage= new JButton("Choose MUI");
				browseimage.setBackground(Color.black);
				browseimage.setForeground(Color.white);
				browseimage.setContentAreaFilled(true);
				browseimage.setOpaque(true);
				browseimage.setFont(font11);
				image.add(pathimage);
				image.add(browseimage);
				evaluate.add(image);
				
				browseimage.addActionListener(new selectFileImage());
						
				
		//new
		JPanel P1= new JPanel ();
	   P1.setBackground(Gold);

		JLabel first = new JLabel ("Enter the DumpFile path:");
		first.setFont(font); 
		JLabel first1 = new JLabel ("---------------------------------");
		first1.setFont(font); 
		P1.add(first);
		P1.add(first1);
		evaluate.add(P1);
		
		//new
		//evaluate.add(P1);
		
		
		
		
		
		JPanel one= new JPanel();
		one.setBackground(Gold);
		 path= new JTextField("",30);
		path.setEditable(false);
		//path.setAlignmentX(JTextField.LEFT_ALIGNMENT);
		browse= new JButton("Choose File");
		browse.setBackground(Color.black);
		browse.setForeground(Color.white);
		browse.setContentAreaFilled(true);
		browse.setOpaque(true);
		browse.setFont(font11);
		one.add(path);
		one.add(browse);
		evaluate.add(one);
		
		browse.addActionListener(new selectFile());
		
		
		JPanel parseView= new JPanel();
		parseView.setBackground(Gold);
		parseView.setLayout(new FlowLayout());
		
		JPanel radios= new JPanel();
		radios.setBackground(Gold);
		radios.setLayout(new BoxLayout(radios,BoxLayout.Y_AXIS));
		
		 group= new ButtonGroup();
		 r1= new JRadioButton("Native Android app ");
		 //r1.setHorizontalTextPosition(SwingConstants.LEFT);
		 r2= new JRadioButton("Hybrid Android app");
		 //r2.setHorizontalTextPosition(SwingConstants.LEFT);
		group.add(r1);
		group.add(r2);
		 radios.add(r1);
		radios.add(r2);
		r1.addActionListener(new check());
		r2.addActionListener(new check());
		parseView.add(radios);
		parse= new JButton("Start parsing");
		parse.setBackground(Color.black);
		parse.setForeground(Color.black);
		parse.setContentAreaFilled(true);
		parse.setOpaque(true);
		parse.setFont(font11);
		 parse.setEnabled(false);
		parse.addActionListener(new parser());
		parseView.add(parse);
		
		UIdata= new JButton ("View MUI components");
		UIdata.setBackground(Color.black);
		UIdata.setForeground(Color.black);
		UIdata.setContentAreaFilled(true);
		UIdata.setOpaque(true);
		UIdata.setFont(font11);
		 UIdata.addActionListener(new ViewElements());
		 UIdata.setEnabled(false);
		 parseView.add(UIdata);
		
		 evaluate.add(parseView);
		 
		 //new
		JPanel P2= new JPanel();
		P2.setBackground(Gold);
		JLabel second = new JLabel ("Xls Output file path:");
		second.setFont(font); 
		JLabel second2 = new JLabel ("-------------------------------------");
		second2.setFont(font); 
		//new
		P2.add(second);
		P2.add(second2);
		//new 
		
		evaluate.add(P2);
		
		//new 
		//JPanel P3= new JPanel();
		 xlspath= new JTextField("",30);
		 xlspath.setEditable(true);
		 JTextFieldRegularPopupMenu.addTo(xlspath);
		 //new
		 //P3.add(xlspath);
		 //evaluate.add(P3);
		evaluate.add(xlspath);
		 
		 
		 JPanel resolutionAndStart = new JPanel();
		 resolutionAndStart.setBackground(Gold);
		 resolutionAndStart.setLayout(new FlowLayout());
		 JPanel resolution = new JPanel();
		 resolution.setLayout(new BoxLayout(resolution,BoxLayout.Y_AXIS));
		 
		 //resolution.setLayout(new FlowLayout((FlowLayout.LEFT)));
		 JPanel frame= new JPanel();
		 frame.setBackground(Gold);
		 JLabel fw= new JLabel("Frame width:");
		  fwt=new JTextField("720",4);
		  fwt.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		 JLabel fh= new JLabel("Frame height:");
		 fht=new JTextField("1280",4);
		 fht.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		 frame.add(fw);
		 frame.add(fwt);
		 frame.add(fh);
		 frame.add(fht);
		 resolution.add(frame);
		 JPanel layout= new JPanel();
		 layout.setBackground(Gold);
		 JLabel lw= new JLabel("Layout width:");
		  lwt=new JTextField("720",4);
		  lwt.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		 JLabel lh= new JLabel("Layout height:");
		  lht=new JTextField("1280",4);
		  lht.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
layout.add(lw);
layout.add(lwt);
layout.add(lh);
layout.add(lht);
resolution.add(layout);
resolutionAndStart.add(resolution);

		Check_TextFields field= new Check_TextFields();
		
		//new
		JPanel start= new JPanel();
		start.setBackground(Gold);
		Start= new JButton ("Start the Evaluation");
		Start.setBackground(Color.black);
		Start.setForeground(Color.black);
		Start.setContentAreaFilled(true);
		Start.setOpaque(true);
		Start.setFont(font11);
		 Start.addActionListener(new StartEvaluation());
		 Start.setEnabled(false);
		 start.add(Start);
		 //new
		// P4.add(Start);
		 //evaluate.add(P4);
		 resolutionAndStart.add(start);
		 evaluate.add(resolutionAndStart);
		/*JPanel p4= new JPanel();
		p4.setBackground(Color.yellow);
		 evaluate.add(p4);*/
		 //new
		 JPanel P5= new JPanel();
		 P5.setBackground(Gold);
		 JLabel metrics= new JLabel("Metrics Evaluation:");
		 metrics.setFont(font); 
		 JLabel metrics2 = new JLabel ("----------------------------------------");
			metrics2.setFont(font); 
		 //new
		 P5.add(metrics);
		 P5.add(metrics2);
		 evaluate.add(P5);
		 //evaluate.add(metrics);
		 // metrics evaluation tab
		 
		 JPanel globemetrics= new JPanel();
		 globemetrics.setLayout(new FlowLayout());
		 globemetrics.setBackground(Gold);
		 JPanel metricsNames= new JPanel();
		 metricsNames.setBackground(Gold);
		 metricsNames.setLayout(new BoxLayout(metricsNames,BoxLayout.Y_AXIS));
		 JPanel MetricsValues = new JPanel();
		 MetricsValues.setBackground(Gold);
		 MetricsValues.setLayout(new BoxLayout(MetricsValues,BoxLayout.Y_AXIS));

		 metricDN= new JPanel();
		 metricDN.setBackground(Gold);
		 metricIM= new JPanel();
		 metricIM.setBackground(Gold);
		 metricOM= new JPanel();
		 metricOM.setBackground(Gold);
		 metricICM= new JPanel();
		 metricICM.setBackground(Gold);
		 metricILW= new JPanel();
		 metricILW.setBackground(Gold);
		 MetricsValues.add(metricDN);
		 MetricsValues.add(metricIM);
		 MetricsValues.add(metricOM);
		 MetricsValues.add(metricICM);
		 MetricsValues.add(metricILW);
		 
		 
		 globemetrics.add(metricsNames);
		 globemetrics.add(MetricsValues);
		 evaluate.add(globemetrics);
		 
		 
		
		 //new
		JPanel P6= new JPanel();
		P6.setBackground(Gold);
		 JLabel defects= new JLabel("Possible Aesthetic Defects:");
		 defects.setAlignmentX(JLabel.LEFT_ALIGNMENT);
		 Font font1 = new Font("Courier", Font.BOLD,12); 
		 defects.setFont(font1); 
		 JLabel defects2 = new JLabel ("--------------------------------");
		defects2.setFont(font); 
		 //new
		P6.add(defects);
		P6.add(defects2);
		 evaluate.add(P6);
		 
	     //evaluate.add(defects); 
	
	
	/* 
     JPanel defectslist = new JPanel();
     defectslist.setBackground(Color.yellow);
      defectslist.setLayout(new GridLayout(5,0));*/
		 
     //DN
	     
	     JPanel globedefects= new JPanel();
		 globedefects.setLayout(new FlowLayout());
		 globedefects.setBackground(Gold);
		 JPanel defectsNames= new JPanel();
		 defectsNames.setBackground(Gold);
		 defectsNames.setLayout(new BoxLayout(defectsNames,BoxLayout.Y_AXIS));
		 JPanel defectsValues = new JPanel();
		 defectsValues.setBackground(Gold);
		 defectsValues.setLayout(new BoxLayout(defectsValues,BoxLayout.Y_AXIS));
	     
		 //JPanel DN1 = new JPanel();
		 //DN1.setBackground(Color.yellow);
		
	     JLabel DNdefect= new JLabel ("(Group 1 of metrics) Difficult Navigation (DN) :: ");
	     //DN1.add(DNdefect);
	     //JPanel OM1 = new JPanel();
	     //OM1.setBackground(Color.yellow);
	     JLabel OMdefect= new JLabel ("(Group 2 of metrics) Overloaded MUI (OM) :: ");
	     //OM1.add(OMdefect);
	     //JPanel IM1 = new JPanel();
	     //IM1.setBackground(Color.yellow);
	     JLabel IMdefect= new JLabel ("(Group 3 of metrics) Imbalanced MUI (IM) :: ");
	     //IM1.add(IMdefect);
	     //JPanel ICM1 = new JPanel();
	     //ICM1.setBackground(Color.yellow);
	     JLabel ICMdefect= new JLabel ("(Group 4 of metrics) In-Cohesion of MUI (ICM) :: ");
	     //ICM1.add(ICMdefect);
	     //JPanel ILW1 = new JPanel();
	     //ILW1.setBackground(Color.yellow);
		 JLabel ILWdefect= new JLabel ("(Group 5 of metrics) Incorrect Layout of Widgets (ILW) :: ");
		 //ILW1.add(ILWdefect);
			  
		 defectsNames.add(DNdefect);
		 defectsNames.add(IMdefect);
		 defectsNames.add(OMdefect);
		 defectsNames.add(ICMdefect);
		 defectsNames.add(ILWdefect);
		 
		 DNstatus= new JLabel();
	     DNstatus.setFont(font11);
	     DNstatus.setForeground(Color.red);
	     OMstatus= new JLabel();
	     OMstatus .setFont(font11);
	     OMstatus.setForeground(Color.red);
	     IMstatus= new JLabel();
	     IMstatus.setFont(font11);
	     IMstatus.setForeground(Color.red);
	     ICMstatus= new JLabel();
	     ICMstatus.setFont(font11);
		 ICMstatus.setForeground(Color.red);
	     ILWstatus= new JLabel();
		 ILWstatus.setFont(font11);
		 ILWstatus.setForeground(Color.red);
		 defectsValues.add(DNstatus);		
		 defectsValues.add(IMstatus);
		 defectsValues.add(OMstatus);
		 defectsValues.add(ICMstatus);
		 defectsValues.add(ILWstatus);
			 
			 
			 
		 globedefects.add(defectsNames);
		 globedefects.add(defectsValues);
		 evaluate.add(globedefects);
		 
    
		 
		 
		 
		 
		 
	}

	public Component getGUI() {
		// TODO Auto-generated method stub
		return evaluate;
	}
	
	class selectFileImage implements ActionListener { 
		public void actionPerformed(ActionEvent Event) { 
		
	        
	        JFileChooser fc = new JFileChooser();
	        fc.setBounds(100, 100, 100, 100);
	        //FileNameExtensionFilter filter = new FileNameExtensionFilter("*.png", "png","*.jpeg", "jpeg");
	        
	        FileNameExtensionFilter filter = new FileNameExtensionFilter( "Image files (*.GIF,*.PNG,*.JPG, *.JPEG)", "GIF","PNG","JPG", "JPEG");
	        fc.setFileFilter(filter);
	       // fc.addChoosableFileFilter(new FileNameExtensionFilter("*.uix", "uix"));
            fc.setCurrentDirectory(new java.io.File("/Desktop"));
            fc.setDialogTitle("MUI image browser...");
            
            fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
           
            if (fc.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION){
                pathimage.setText(fc.getSelectedFile().getAbsolutePath());
            }
	        
	        
	        
		}

	}	
		//######## Browse button
	class selectFile implements ActionListener { 
		public void actionPerformed(ActionEvent Event) { 
		
	        
	        JFileChooser fc = new JFileChooser();
	        fc.setBounds(100, 100, 100, 100);
	        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.uix", "uix");
	        fc.setFileFilter(filter);
	       // fc.addChoosableFileFilter(new FileNameExtensionFilter("*.uix", "uix"));
            fc.setCurrentDirectory(new java.io.File("/Desktop"));
            fc.setDialogTitle("File Browser...");
            
            fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
           
            if (fc.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION){
                path.setText(fc.getSelectedFile().getAbsolutePath());
            }
	        
	        
	        
		}

	}	
	
		
		
	//######## parse button
		
	class parser implements ActionListener {  
		@SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent Event) { 
			nativeApps parsernative = new nativeApps(); //instantiating the class 
			hybridApps parserhybrid= new hybridApps();
			
			if (r1.isSelected())
				{try {
					parsernative.main(new String[]{});
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}}
			else if (r2.isSelected())
			{
				try {
					parserhybrid.main(new String[]{});
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			//Framework.deleteEvaluation.setEnabled(true);
			//Framework.deleteEvaluation.setForeground(Color.white);
		}

	}	
			
		
	//######## view button
	
		class ViewElements implements ActionListener {  
			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent Event) { 
			
		   
				ViewUIComponent dialog = null;
				try {
					dialog = new ViewUIComponent();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				dialog.main(new String[]{});
			}

		}	
			
		//######## view button
		
			class StartEvaluation implements ActionListener {  
				@SuppressWarnings("static-access")
				public void actionPerformed(ActionEvent Event) { 
					
					main_launcher eval = new main_launcher(); //instantiating the class 
					
					try {
						eval.main(new String[]{});
					} /*catch (Exception e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
						StringBuilder sb = new StringBuilder(e.toString());
					    for (StackTraceElement ste : e.getStackTrace()) {
					        sb.append("\n\tat ");
					        sb.append(ste);
					    
					    trace = sb.toString();
					
					}
					    JOptionPane.showMessageDialog(null, trace, "Warning", JOptionPane.ERROR_MESSAGE);
					}  */ 
					catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();

					    StringBuilder sb = new StringBuilder(e.toString());
					    for (StackTraceElement ste : e.getStackTrace()) {
					        sb.append("\n\tat ");
					        sb.append(ste);
					    
					     trace = sb.toString();
					
					
					} JOptionPane.showMessageDialog(null, "FileNotFoundException"+"\n"+"re-check your xls file format!", "Warning", JOptionPane.ERROR_MESSAGE);
					}
	                catch (IOException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
						
						    StringBuilder sb = new StringBuilder(e.toString());
						    for (StackTraceElement ste : e.getStackTrace()) {
						        sb.append("\n\tat ");
						        sb.append(ste);
						    
						    trace = sb.toString();
						
						
					}
						    JOptionPane.showMessageDialog(null, "IOException"+"\n"+"re-check your xls file format!", "Warning", JOptionPane.ERROR_MESSAGE);
	                }
	                catch(IllegalStateException e)
	                
	                {   StringBuilder sb = new StringBuilder(e.toString());
				    for (StackTraceElement ste : e.getStackTrace()) {
				        sb.append("\n\tat ");
				        sb.append(ste);
				    
				    trace = sb.toString();
				
				
			}
				    JOptionPane.showMessageDialog(null, "IllegalStateException"+"\n"+"re-check your xls file format!", "Warning", JOptionPane.ERROR_MESSAGE);
            }
            catch(NullPointerException e)
	                
	                {   StringBuilder sb = new StringBuilder(e.toString());
				    for (StackTraceElement ste : e.getStackTrace()) {
				        sb.append("\n\tat ");
				        sb.append(ste);
				    
				    trace = sb.toString();
				
				
			}
				    JOptionPane.showMessageDialog(null, "NullPointerException"+"\n"+"re-check your xls file format!", "Warning", JOptionPane.ERROR_MESSAGE);
            }
					  
					if(main_launcher.difficult1.equals(""))
					  { DNstatus.setForeground(Color.black);
						DNstatus.setText("---");}
					else {
						DNstatus.setForeground(Color.red);
						DNstatus.setText(main_launcher.difficult1);}
					
					if(main_launcher.balanced1.equals(""))
					{   IMstatus.setForeground(Color.black);
						IMstatus.setText("---");}
					else {
						IMstatus.setForeground(Color.red);
						IMstatus.setText(main_launcher.balanced1);}
					 
					if(main_launcher.overloaded1.equals(""))
					{   OMstatus.setForeground(Color.black);
						OMstatus.setText("---");}
					else 
					{	OMstatus.setForeground(Color.red); 
						OMstatus.setText(main_launcher.overloaded1);}
				
					if (main_launcher.cohesioned1.equals(""))
					{   ICMstatus.setForeground(Color.black);
						ICMstatus.setText("---");}
					else
					{   ICMstatus.setForeground(Color.red);
						ICMstatus.setText(main_launcher.cohesioned1);}
					  
					if(main_launcher.layout1.equals(""))
					{   ILWstatus.setForeground(Color.black);
						ILWstatus.setText("---");}
					else
					{   ILWstatus.setForeground(Color.red);
						ILWstatus.setText(main_launcher.layout1);}
					
					Recommendations.FillRemarksTabs remarks= new Recommendations.FillRemarksTabs ();
					  remarks.main(new String[]{});
					  if ((pathimage.getText().isEmpty()))
					  {JOptionPane.showMessageDialog(null, "Provide the path to you user interface image before generating the recommendations!", "Warning", JOptionPane.ERROR_MESSAGE);
						}  
					  recomendations.generateRecommendations.setEnabled(true);
					  recomendations.generateRecommendations.setForeground(Color.white);
					  
					
					  Start.setEnabled(false);
					  Start.setForeground(Color.black);
					  //Framework.frame.setSize(Framework.screenWidth,750);
					  //Framework.frame.setLocationRelativeTo(null);
					
					  
					  
				}

			}	
	
	
	
	
			
					//######## check radios
					
					class check implements ActionListener {  
						@SuppressWarnings("static-access")
						public void actionPerformed(ActionEvent Event) { 
						
							Event.getSource();
						
                        if (r1.isSelected() &&!(path.getText().trim().length() == 0)
                        		)
                        {
                        	parse.setEnabled(true); parse.setForeground(Color.white);
                        }
                        else if (r2.isSelected() &&!(path.getText().trim().length() == 0))
                        {
                        	parse.setEnabled(true);parse.setForeground(Color.white);
                        }
					}	
			}
	
	
	
	
	}


