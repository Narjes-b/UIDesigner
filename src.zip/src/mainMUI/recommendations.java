package mainMUI;

/**
 * @author bessghaiernarjess
 */
public class recommendations {

	public recommendations() {
		// TODO Auto-generated constructor stub
	}

}
