package mainMUI;
import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import Parser.nativeApps;

/**
 * @author bessghaiernarjess
 */
public class ViewUIComponent extends javax.swing.JFrame{
	private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
	int indice_X=0;
	int indice_Y=0;
	int indice_width=0;
	int indice_height=0;
	int indice_nature=0;
	int indice_text=0;
	int indice_hint=0;
	String [] nature,text,hint;
	public static final Color Gold = new Color(255,204,51);
	int [] Ytab,Xtab,width,height;
	 static String trace;
	 public ViewUIComponent() throws FileNotFoundException, IOException {
	        initComponents();

	         // use the addRowToJTable
	        addRowToJTable();

	    }
	 
	 public void getData () throws FileNotFoundException,IOException
	 {
		 String file= nativeApps.outputFile;
			
			//InputStream input = new FileInputStream(file);
			InputStream input = new FileInputStream(evaluate.xlspath.getText());
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
			 //row number
			 
			 int rowTotal = sheet.getLastRowNum();
		
	     if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	         rowTotal++;
	     }
	   	
	     for ( int r=0;r<1; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=0;c<noOfColumns; c++)
		    	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				 String text= cell.getStringCellValue();
				 //System.out.println("text="+text);
				 if (text.equals("x"))
				 {
					indice_X=c; 
					//System.out.println(indice_width);
				 }
				 
				 if (text.equals("y"))
				 {
					indice_Y=c; 
					//System.out.println(indice_height);
				 } 
				 
				 if (text.equals("width"))
				 {
					indice_width=c; 
					//System.out.println(indice_width);
				 }
				 
				 if (text.equals("height"))
				 {
					indice_height=c; 
					//System.out.println(indice_height);
				 } 
				 
	  			 if (text.equals("nature"))
	  			 {
	  				 indice_nature=c; 
	  				//System.out.println(indice_width);
	  			 }
	  			 
	  			 if (text.equals("text"))
	  			 {
	  				indice_text=c; 
	  				//System.out.println(indice_height);
	  			 } 
				 
			        }
				 }
	     
	 
	     
	      Xtab=new int[rowTotal]; 
		  Ytab=new int[rowTotal]; 
		  nature=new String[rowTotal]; 
	  	  text=new String[rowTotal]; 
	  	  width=new int[rowTotal]; 
		  height=new int[rowTotal]; 
		  hint=new String[rowTotal];
		  
	     for ( int r=1;r<rowTotal; r++)
	     
	     {   
	   	  HSSFRow row     = sheet.getRow(r); 
	   	  
	   	  //fill the X table
	   	  for (int c=indice_X;c<indice_X+1; c++)
	 	        
		        {
	   		  HSSFCell cell= row.getCell(c);
	   		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	   		  Xtab[r-1]= (int)(cell.getNumericCellValue());
	   		 
		        }
	   	  
	   	  
	   	//fill the Y table
	   	  
	   	  for (int c=indice_Y;c<indice_Y+1; c++)
	   	        
		        {
	 		  HSSFCell cell= row.getCell(c);
	 		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	 		  Ytab[r-1]= (int)(cell.getNumericCellValue());
	 	
		        }
	     
	     
	   //fill the width table
   	  for (int c=indice_width;c<indice_width+1; c++)
 	        
	        {
   		  HSSFCell cell= row.getCell(c);
   		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
   		  width[r-1]= (int)(cell.getNumericCellValue());
   		  
	        }
   	  
   	//fill the height table
   	  
   	  for (int c=indice_height;c<indice_height+1; c++)
   	        
	        {
 		  HSSFCell cell= row.getCell(c);
 		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
 		  height[r-1]= (int)(cell.getNumericCellValue());
 		  
	        }
	
	   	  //fill the nature table
	   	  for (int c=indice_nature;c<indice_nature+1; c++)
	 	        
		        {
	   		  HSSFCell cell= row.getCell(c);
	   		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	   		  nature[r-1]= (cell.getStringCellValue());
	   		  
		        }
	   	  
	   	//fill the text table
	   	  
	   	  for (int c=indice_text;c<indice_text+1; c++)
	   	        
		        {
	 		  HSSFCell cell= row.getCell(c);
	 		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	 		  text[r-1]= (cell.getStringCellValue());
	 		  
		        }
	   
	     }
	     
	     
	 	/*for ( int r=1;r<rowTotal; r++)
		     
	     {   
	   	  HSSFRow row     = sheet.getRow(r);  	  
//fill the hint table
	   	  
	   	  for (int c=14;c<15; c++)
	   	        
		        {
	 		  HSSFCell cell= row.getCell(c);
	 		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	 		  hint[r-1]= (cell.getStringCellValue());
	 		  
		        }}  */
	     
	     
	     //afficher nature
	     for (int i = 0; i < nature.length-1; ++i) { 
	      	
	      	//System.out.println("nature::"+nature[i]);	
	      }
	     
	     //afficher xtab et ytab
	     for (int k = 0; k < Xtab.length-1; ++k) { 
	 			//System.out.println("X::"+Xtab[k]);
	 			
	 		}
	    
	     for (int k = 0; k < Ytab.length-1; ++k) { 
	 		//System.out.println("Y::"+Ytab[k]);
	 			
	 		}
	   //afficher width et height
	     for (int k = 0; k < width.length-1; ++k) { 
	 			//System.out.println("w::"+width[k]);
	 			
	 		}
	    
	     for (int k = 0; k < height.length-1; ++k) { 
	 		//System.out.println("h::"+height[k]);
	 			
	 		}
			
	     //afficher text
	         for (int i = 0; i < text.length-1; ++i) { 
	         	
	         	//System.out.println("text::"+text[i]);	
	         }
	         
	 }

	// added rows from arraylist to jtable
	    public void addRowToJTable() throws FileNotFoundException, IOException
	    {
	    	getData();
	        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
	       // ArrayList<data> list = ListData();
	        Object rowData[] = new Object[6];
	        for(int i = 0; i < nature.length-1; i++)
	        {
	            rowData[0] = nature[i];
	            rowData[1] = Xtab[i];
	            rowData[2] = Ytab[i];
	            rowData[3] = width[i];
	            rowData[4] = height[i];
	            rowData[5] = text[i];
	            //rowData[6] = hint[i];
	            model.addRow(rowData);
	        }
	                
	    }


	    @SuppressWarnings("unchecked")
	                          
	    private void initComponents() {

	        jScrollPane1 = new javax.swing.JScrollPane();
	        jTable1 = new javax.swing.JTable();
	       
	        jTable1.setModel(new javax.swing.table.DefaultTableModel(
	            new Object [][] {

	            },
	            new String [] {
	                "Name", "X", "Y", "Width","Height","Text"
	            }
	        ));
	        jScrollPane1.setViewportView(jTable1);
	        getContentPane().add(jScrollPane1);
	        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setAutoCreateGaps(true);
	        layout.setAutoCreateContainerGaps(true);
	        
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
	            .addGroup(layout.createSequentialGroup()
	              .addGap(0,10,10)
	                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
	              
	                )
	);
	       layout.setVerticalGroup(
	            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	           .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
	            	
	                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
	              
	                )
	        );

	      
	        pack();
	    }                      

	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String args[]) {
	  
	    	
	        try {
	            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } 
	        
	      
	        catch (ClassNotFoundException ex) {
	           java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {	        
	            java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {	        
	            java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (javax.swing.UnsupportedLookAndFeelException ex) {	        	
	            java.util.logging.Logger.getLogger(ViewUIComponent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }

	        /* Create and display the form */
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                try {
	                	ViewUIComponent frame=new ViewUIComponent();
	                	frame.setVisible(true);
						frame.getContentPane().setBackground(Gold);
						frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
						 frame.setLocationRelativeTo(null);
						 frame.setTitle(" User Interface Components Geometrical data");
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();

					    StringBuilder sb = new StringBuilder(e.toString());
					    for (StackTraceElement ste : e.getStackTrace()) {
					        sb.append("\n\tat ");
					        sb.append(ste);
					    
					     trace = sb.toString();
					
					
					} JOptionPane.showMessageDialog(null, "FileNotFoundException"+"\n"+"re-check your input!", "Warning", JOptionPane.ERROR_MESSAGE);
					}
              catch(NullPointerException e)
	                
	                {   StringBuilder sb = new StringBuilder(e.toString());
				    for (StackTraceElement ste : e.getStackTrace()) {
				        sb.append("\n\tat ");
				        sb.append(ste);
				    
				    trace = sb.toString();
				
				
			}
				    JOptionPane.showMessageDialog(null, "NullPointerException"+"\n"+"re-check your input!", "Warning", JOptionPane.ERROR_MESSAGE);
            }
	                catch (IOException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
						
						    StringBuilder sb = new StringBuilder(e.toString());
						    for (StackTraceElement ste : e.getStackTrace()) {
						        sb.append("\n\tat ");
						        sb.append(ste);
						    
						    trace = sb.toString();
						
						
					}
						    JOptionPane.showMessageDialog(null, "IOException"+"\n"+"re-check your input!", "Warning", JOptionPane.ERROR_MESSAGE);
	                }
	                catch(IllegalStateException e)
	                
	                {   StringBuilder sb = new StringBuilder(e.toString());
				    for (StackTraceElement ste : e.getStackTrace()) {
				        sb.append("\n\tat ");
				        sb.append(ste);
				    
				    trace = sb.toString();
				
				
			}
				    JOptionPane.showMessageDialog(null, "IllegalStateException"+"\n"+"re-check your input!", "Warning", JOptionPane.ERROR_MESSAGE);
            }
            
	            }
	        });
	    }

	    
	   
}
